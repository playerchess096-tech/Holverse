package com.magialuama.horrorverse;

import java.util.*;
import net.minecraft.commands.arguments.EntityAnchorArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/** Entità principale del mod: una sola classe per tutte e sei, con comportamento deciso da {@link Kind} e dal livello. */
public class HorrorBoss extends PathfinderMob {
    public static final int PRESENCE = 0, FIGHT = 1, CHOICE = 2;
    private static final EntityDataAccessor<Integer> LEVEL = SynchedEntityData.defineId(HorrorBoss.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> VARIANT = SynchedEntityData.defineId(HorrorBoss.class, EntityDataSerializers.INT);

    public final Kind kind;
    public final ServerBossEvent bossBar;
    public int mode = PRESENCE, fightTick, lifeTicks, phase, a, b, c, d, hitCount, sightings;
    public long lastHit;
    public double gaze;
    public boolean window, restored;
    public int windowTicks;
    public UUID focus;
    public Vec3 arena;
    public final Set<UUID> minions = new HashSet<>();
    public final List<BlockPos> marks = new ArrayList<>();
    public final List<BlockPos> tempPos = new ArrayList<>();
    public final List<Block> tempBlk = new ArrayList<>();
    public final List<ItemStack> stolen = new ArrayList<>();
    public final Map<String, Integer> mem = new HashMap<>();
    public final List<double[]> zones = new ArrayList<>();   // x,y,z,raggio,scadenza(tick),danno
    public final List<BlockPos> statues = new ArrayList<>();
    public final List<BlockPos> depots = new ArrayList<>();
    public final List<double[]> pending = new ArrayList<>();   // meteoriti: x,y,z,tick,danno
    public int cageUntil, burstStart, burstN;

    public HorrorBoss(EntityType<? extends PathfinderMob> type, Level level, Kind kind) {
        super(type, level);
        this.kind = kind;
        this.bossBar = new ServerBossEvent(UUID.randomUUID(), Component.literal(kind.nameIt), kind.bar, net.minecraft.world.BossEvent.BossBarOverlay.PROGRESS);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder attrs() {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 100.0).add(Attributes.MOVEMENT_SPEED, 0.3)
                .add(Attributes.ATTACK_DAMAGE, 6.0).add(Attributes.FOLLOW_RANGE, 64.0).add(Attributes.KNOCKBACK_RESISTANCE, 0.9);
    }

    @Override protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(LEVEL, 1);
        builder.define(VARIANT, 0);
    }
    @Override protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(7, new WaterAvoidingRandomStrollGoal(this, 0.7D));
        goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 10.0F));
        goalSelector.addGoal(9, new RandomLookAroundGoal(this));
    }
    @Override public boolean removeWhenFarAway(double dist) { return false; }

    public int lvl() { return this.entityData.get(LEVEL); }
    public int variant() { return this.entityData.get(VARIANT); }
    public void setVariant(int v) { if (variant() != v) this.entityData.set(VARIANT, v); }
    public void setLvl(int l) {
        Store.ensure(level().getServer());
        Store.setBossLevel(getUUID(), l);
        this.entityData.set(LEVEL, l);
        applyStats();
    }
    private void restoreFromTags() {
        Store.ensure(level().getServer());
        int l = Store.bossLevel(getUUID());
        if (l > 0) { this.entityData.set(LEVEL, l); applyStats(); }
    }
    private void setAttr(Holder<Attribute> attr, double v) { AttributeInstance i = getAttribute(attr); if (i != null) i.setBaseValue(v); }
    public void applyStats() {
        int l = lvl();
        double hp = Balance.hp(kind, l) * Config.HEALTH_MULT.get();
        setAttr(Attributes.MAX_HEALTH, hp);
        setHealth((float) hp);
        setAttr(Attributes.ATTACK_DAMAGE, Balance.dmg(kind, l) * Config.DAMAGE_MULT.get());
        setAttr(Attributes.MOVEMENT_SPEED, Balance.speed(kind, l) * Config.SPEED_MULT.get());
        setAttr(Attributes.SCALE, kind == Kind.OSSERVATORE ? 1.12 : 1.0);
    }

    public static final class Balance {
        private Balance() {}
        private static double pick(double[] a, int l) { return a[Math.max(0, Math.min(a.length - 1, l))]; }
        public static double hp(Kind k, int l) {
            return switch (k) {
                case CUSTODE -> pick(new double[]{100, 100, 120, 200, 320, 360}, l);
                case CORROTTO -> pick(new double[]{150, 150, 180, 220, 260, 380}, l);
                case ENTITY404 -> pick(new double[]{100, 100, 150, 240, 300, 220, 600, 1200}, l);
                case MAGO -> pick(new double[]{80, 80, 100, 180, 260, 340}, l);
                case STEVE -> pick(new double[]{60, 60, 100, 160, 240, 320}, l);
                case OSSERVATORE -> 40;
            };
        }
        public static double dmg(Kind k, int l) {
            return switch (k) {
                case CUSTODE -> pick(new double[]{6, 6, 7, 8, 10, 10}, l);
                case CORROTTO -> pick(new double[]{8, 8, 9, 10, 12, 14}, l);
                case ENTITY404 -> pick(new double[]{6, 6, 7, 9, 11, 12, 15, 18}, l);
                case MAGO -> pick(new double[]{5, 5, 6, 7, 8, 10}, l);
                case STEVE -> pick(new double[]{4, 4, 6, 8, 10, 12}, l);
                case OSSERVATORE -> 0;
            };
        }
        public static double speed(Kind k, int l) {
            return switch (k) {
                case CUSTODE -> pick(new double[]{0.30, 0.30, 0.32, 0.32, 0.34, 0.36}, l);
                case CORROTTO -> 0.28 + 0.01 * l;
                case ENTITY404 -> 0.30 + 0.005 * l;
                case MAGO -> 0.26;
                case STEVE -> 0.28 + 0.01 * l;
                case OSSERVATORE -> 0.25;
            };
        }
    }

    // ------------------------------------------------------------------ ciclo di vita
    @Override public void tick() {
        super.tick();
        if (level().isClientSide()) return;
        ServerLevel lv = (ServerLevel) level();
        lifeTicks++;
        if (!restored) { restored = true; restoreFromTags(); }
        Brains.tick(this, lv);
    }

    public ServerPlayer focusPlayer(ServerLevel lv) { return focus == null ? null : lv.getServer().getPlayerList().getPlayer(focus); }
    public boolean every(int n) { return n > 0 && fightTick % Math.max(1, (int) Math.round(n * Config.ABILITY_CD_MULT.get())) == 0; }
    public void face(Entity e) { lookAt(EntityAnchorArgument.Anchor.EYES, e.getEyePosition()); }

    public void startFight(ServerPlayer p, ServerLevel lv) {
        mode = FIGHT; focus = p.getUUID(); fightTick = 0; phase = 0; a = 0; b = 0; c = 0; d = 0; hitCount = 0; window = false; windowTicks = 0;
        setNoAi(false);
        applyStats();
        arena = position();
        bossBar.setName(Component.literal(kind.nameIt + " — " + Lore.levelName(kind, lvl())));
        bossBar.setProgress(1.0f);
        Progress.addCtr(p, "enc." + kind.id, 1);
        Progress.setCtr(p, "lastfight", Math.max(1, Progress.minutes(p)));
        Fx.title(p, kind.nameIt, Lore.levelName(kind, lvl()));
        Fx.soundTo(p, ModSounds.theme(kind).get(), 0.7f, 1.0f);
        Fx.say(p, kind, Lore.taunt(getRandom(), kind, lvl()));
        Brains.onStart(this, lv, p);
    }

    void fightLogic(ServerLevel lv) {
        fightTick++;
        ServerPlayer p = focusPlayer(lv);
        if (p == null || !p.isAlive() || p.level() != lv || distanceToSqr(p) > 110.0 * 110.0) { end(false, p); return; }
        if (fightTick > Config.ENTITY_PERSIST.get() * 20) { Fx.say(p, kind, "Basta così. Non ho più tempo per te."); end(false, p); return; }
        if (windowTicks > 0 && --windowTicks == 0) window = false;
        if (window && fightTick % 10 == 0) Fx.particles(lv, ParticleTypes.END_ROD, getX(), getY() + 1.0, getZ(), 6, 0.4, 0.8, 0.4, 0.02);
        if (fightTick % 10 == 0) updateBar(lv);
        runZones(lv, p);
        Fights.poll(this, lv, p);
        Brains.fight(this, lv, p);
    }

    private void updateBar(ServerLevel lv) {
        bossBar.setProgress(Math.max(0.0f, Math.min(1.0f, getHealth() / getMaxHealth())));
        for (ServerPlayer sp : lv.players()) {
            if (sp.distanceToSqr(this) < 80.0 * 80.0) bossBar.addPlayer(sp); else bossBar.removePlayer(sp);
        }
    }

    public void zone(ServerLevel lv, double x, double y, double z, double r, int ticks, double dmg) {
        zones.add(new double[]{x, y, z, r, fightTick + ticks, dmg});
    }
    private void runZones(ServerLevel lv, ServerPlayer p) {
        pending.removeIf(m -> {
            if (fightTick % 5 == 0) Fx.particles(lv, ParticleTypes.FLAME, m[0], m[1] + 0.2, m[2], 6, 1.2, 0.05, 1.2, 0.01);
            if (fightTick < m[3]) return false;
            Fx.particles(lv, ParticleTypes.EXPLOSION, m[0], m[1] + 1.0, m[2], 3, 1.0, 0.5, 1.0, 0.0);
            Fx.sound(lv, m[0], m[1], m[2], ModSounds.THUNDER_FAR.get(), 0.8f, 1.4f);
            double dx = p.getX() - m[0], dz = p.getZ() - m[2];
            if (dx * dx + dz * dz < 12.25 && Math.abs(p.getY() - m[1]) < 4.0) Fx.hurt(p, lv.damageSources().magic(), (float) m[4]);
            return true;
        });
        zones.removeIf(z -> fightTick > z[4]);
        for (double[] z : zones) {
            if (fightTick % 6 == 0) Fx.particles(lv, kind == Kind.ENTITY404 ? Fx.GREEN : ParticleTypes.ELECTRIC_SPARK, z[0], z[1] + 0.3, z[2], 6, z[3] * 0.5, 0.2, z[3] * 0.5, 0.01);
            double dx = p.getX() - z[0], dz = p.getZ() - z[2];
            if (fightTick % 20 == 0 && dx * dx + dz * dz < z[3] * z[3] && Math.abs(p.getY() - z[1]) < 3.0)
                Fx.hurt(p, lv.damageSources().magic(), (float) z[5]);
        }
    }

    /** Fine dello scontro. Ritorna dopo aver pulito arena, mostri e oggetti temporanei. */
    public void end(boolean victory, ServerPlayer p) {
        ServerLevel lv = (ServerLevel) level();
        cleanup(lv);
        if (p != null) { Fx.cleanItems(p, "hv_locked"); Fx.removeDecoys(p); }
        boolean keep = false;
        if (victory && p != null) keep = Rewards.victory(this, lv, p);
        else if (p != null && mode == FIGHT) { Fx.say(p, kind, "Non sei ancora pronto."); Progress.addCtr(p, "fail." + kind.id, 1); }
        if (!keep) {
            Fx.particles(lv, ParticleTypes.PORTAL, getX(), getY() + 1.0, getZ(), 60, 0.5, 1.0, 0.5, 0.3);
            discard();
        }
    }

    public void cleanup(ServerLevel lv) {
        for (UUID id : new ArrayList<>(minions)) { Entity e = lv.getEntity(id); if (e != null) e.discard(); }
        minions.clear();
        for (int i = 0; i < tempPos.size(); i++) if (lv.getBlockState(tempPos.get(i)).is(tempBlk.get(i))) lv.removeBlock(tempPos.get(i), false);
        tempPos.clear(); tempBlk.clear();
        for (BlockPos mp : marks) if (Structures.isTemp(lv.getBlockState(mp))) lv.removeBlock(mp, false);
        marks.clear();
        for (BlockPos dp : depots) if (lv.getBlockState(dp).is(net.minecraft.world.level.block.Blocks.CHEST)) lv.removeBlock(dp, false);
        depots.clear();
        returnStolen(lv);
        bossBar.removeAllPlayers();
        zones.clear(); pending.clear();
    }
    public void returnStolen(ServerLevel lv) {
        for (ItemStack s : stolen) Containers.dropItemStack(lv, getX(), getY(), getZ(), s);
        stolen.clear();
        setItemSlot(net.minecraft.world.entity.EquipmentSlot.MAINHAND, ItemStack.EMPTY);
    }

    /** Colpo letale intercettato: sconfitta narrativa. */
    public void defeat(ServerPlayer p) { end(true, p); }

    // ------------------------------------------------------------------ strumenti per le abilità
    public void tempBlock(ServerLevel lv, BlockPos pos, BlockState st) {
        if (!lv.getBlockState(pos).isAir()) return;
        tempPos.add(pos); tempBlk.add(st.getBlock()); lv.setBlock(pos, st, 3);
    }
    public void chase(ServerPlayer p, double speed) {
        getLookControl().setLookAt(p, 30.0f, 30.0f);
        if (tickCount % 8 == 0) getNavigation().moveTo(p, speed);
    }
    public void melee(ServerPlayer p, double reach, int cd) {
        if (distanceToSqr(p) <= reach * reach && fightTick % cd == 0) {
            Fx.hurt(p, damageSources().mobAttack(this), (float) getAttributeValue(Attributes.ATTACK_DAMAGE));
        }
    }
    public void tpTo(ServerLevel lv, double x, double y, double z) {
        Fx.particles(lv, ParticleTypes.PORTAL, getX(), getY() + 1.0, getZ(), 25, 0.3, 0.6, 0.3, 0.2);
        Fx.moveTo(this, x, y, z);
        Fx.particles(lv, ParticleTypes.PORTAL, x, y + 1.0, z, 25, 0.3, 0.6, 0.3, 0.2);
        Fx.sound(lv, x, y, z, ModSounds.TELEPORT_BLIP.get(), 0.6f, 1.0f);
    }
    public void tpNear(ServerLevel lv, ServerPlayer p, double r) { Vec3 v = Fx.ring(lv, p.position(), r * 0.8, r * 1.2); tpTo(lv, v.x, v.y, v.z); }
    public void tpBehind(ServerLevel lv, ServerPlayer p, double dist) {
        Vec3 back = p.getLookAngle().multiply(-1.0, 0.0, -1.0).normalize().scale(dist);
        double x = p.getX() + back.x, z = p.getZ() + back.z;
        tpTo(lv, x, Fx.groundY(lv, x, z), z);
    }

    public void cleanDead(ServerLevel lv) { minions.removeIf(id -> { Entity e = lv.getEntity(id); return e == null || !e.isAlive(); }); }
    public Minion minion(ServerLevel lv, MinionType t, double x, double y, double z) {
        cleanDead(lv);
        if (minions.size() >= Config.MAX_MINIONS.get()) return null;
        Minion m = Fx.spawn(lv, ModEntities.MINIONS.get(t).get(), x, y, z);
        if (m != null) { m.owner = getUUID(); minions.add(m.getUUID()); }
        return m;
    }
    public int alive(ServerLevel lv, MinionType t) {
        int n = 0;
        for (UUID id : minions) { Entity e = lv.getEntity(id); if (e instanceof Minion m && m.isAlive() && m.type == t) n++; }
        return n;
    }
    public int aliveAll(ServerLevel lv) { cleanDead(lv); return minions.size(); }
    public void wave(ServerLevel lv, ServerPlayer p, MinionType t, int n) {
        for (int i = 0; i < n; i++) { Vec3 v = Fx.ring(lv, p.position(), 5.0, 10.0); minion(lv, t, v.x, v.y, v.z); }
        Fx.sound(lv, p.getX(), p.getY(), p.getZ(), ModSounds.DRONE_LOW.get(), 0.8f, 1.0f);
    }
    public void strike(ServerLevel lv, ServerPlayer p, float dmg) {
        Fx.bolt(lv, p.getX(), p.getY(), p.getZ());
        float x = p.hasEffect(ModEffects.SCUDO_EDEN) ? dmg * 0.5f : dmg;
        Fx.hurt(p, lv.damageSources().lightningBolt(), x * Config.DAMAGE_MULT.get().floatValue());
    }
    public void beam(ServerLevel lv, LivingEntity t, float dmg, ParticleOptions o) {
        Fx.beam(lv, getEyePosition(), t.getEyePosition().add(0.0, -0.3, 0.0), o);
        Fx.hurt(t, lv.damageSources().magic(), dmg * Config.DAMAGE_MULT.get().floatValue());
    }
    public void setWindow(ServerLevel lv, int ticks) {
        window = true; windowTicks = ticks;
        Fx.sound(lv, getX(), getY(), getZ(), ModSounds.BELL_TOLL.get(), 0.7f, 1.4f);
    }
    public void say(ServerPlayer p, String s) { Fx.say(p, kind, s); }
    public void sayRandom(ServerPlayer p) { Fx.say(p, kind, Lore.taunt(getRandom(), kind, lvl())); }
}
