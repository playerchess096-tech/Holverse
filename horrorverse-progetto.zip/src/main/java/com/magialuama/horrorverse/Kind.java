package com.magialuama.horrorverse;

import net.minecraft.ChatFormatting;
import net.minecraft.resources.Identifier;
import net.minecraft.world.BossEvent;

public enum Kind {
    OSSERVATORE("osservatore", "L'Osservatore", 1, 3, ChatFormatting.GRAY, BossEvent.BossBarColor.WHITE),
    STEVE("steve", "Steve", 1, 5, ChatFormatting.AQUA, BossEvent.BossBarColor.BLUE),
    CUSTODE("custode", "Il Custode", 2, 5, ChatFormatting.WHITE, BossEvent.BossBarColor.WHITE),
    MAGO("uomo_magico", "L'Uomo Magico", 3, 5, ChatFormatting.LIGHT_PURPLE, BossEvent.BossBarColor.PURPLE),
    CORROTTO("corrotto", "Il Corrotto", 4, 5, ChatFormatting.DARK_PURPLE, BossEvent.BossBarColor.PINK),
    ENTITY404("entity_404", "Entity 404", 5, 7, ChatFormatting.GREEN, BossEvent.BossBarColor.GREEN);

    public final String id, nameIt;
    public final int chapter, maxLevel;
    public final ChatFormatting chat;
    public final BossEvent.BossBarColor bar;

    Kind(String id, String nameIt, int chapter, int maxLevel, ChatFormatting chat, BossEvent.BossBarColor bar) {
        this.id = id; this.nameIt = nameIt; this.chapter = chapter; this.maxLevel = maxLevel; this.chat = chat; this.bar = bar;
    }

    public Identifier texture(int level, int variant) {
        String n = switch (this) {
            case CUSTODE -> "custode";
            case OSSERVATORE -> "osservatore";
            case MAGO -> "mago";
            case STEVE -> "steve_" + Math.max(1, Math.min(5, level));
            case CORROTTO -> "corrotto_" + Math.max(0, Math.min(2, variant));
            case ENTITY404 -> level >= 4 ? "e404_b" : "e404_a";
        };
        return Fx.id("textures/entity/" + n + ".png");
    }
}
