package com.magialuama.horrorverse;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.neoforged.neoforge.registries.DeferredHolder;

public final class ModEffects {
    private ModEffects() {}
    public static final DeferredHolder<MobEffect, MarkerEffect> CORRUZIONE = Reg.EFFECTS.register("corruzione", () -> new MarkerEffect(MobEffectCategory.HARMFUL, 0x4B1B6E));
    public static final DeferredHolder<MobEffect, MarkerEffect> SCUDO_EDEN = Reg.EFFECTS.register("scudo_eden", () -> new MarkerEffect(MobEffectCategory.BENEFICIAL, 0xFFD24A));
    public static final DeferredHolder<MobEffect, MarkerEffect> SGUARDO = Reg.EFFECTS.register("sguardo", () -> new MarkerEffect(MobEffectCategory.HARMFUL, 0xDDDDDD));
    public static final DeferredHolder<MobEffect, MarkerEffect> PIAGA = Reg.EFFECTS.register("piaga", () -> new MarkerEffect(MobEffectCategory.HARMFUL, 0x3CFF5A));
    public static final DeferredHolder<MobEffect, MarkerEffect> MALEDIZIONE_RUNICA = Reg.EFFECTS.register("maledizione_runica", () -> new MarkerEffect(MobEffectCategory.HARMFUL, 0x8A4FFF));
    public static final DeferredHolder<MobEffect, MarkerEffect> PUREZZA = Reg.EFFECTS.register("purezza", () -> new MarkerEffect(MobEffectCategory.BENEFICIAL, 0xAEF3FF));
    public static void init() { }
}
