package com.magialuama.horrorverse;

import java.util.ArrayList;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Blocks;

/** "Dimensione" di Entity 404: una piattaforma lontana nell'Overworld (nessun salvataggio toccato), con il Cuore da distruggere. */
public final class Pocket {
    private Pocket() {}
    public static final BlockPos CENTER = new BlockPos(1_000_000, 150, 1_000_000);

    public static boolean inside(ServerPlayer p) { return Math.abs(p.getX() - CENTER.getX()) < 40 && Math.abs(p.getZ() - CENTER.getZ()) < 40; }

    public static void enter(ServerPlayer p, ServerLevel from) {
        if (!Config.POCKET.get() || inside(p)) return;
        ServerLevel ow = from.getServer().overworld();
        build(ow);
        Store.ensure(from.getServer());
        Store.put(p.getUUID(), "ret", (int) p.getX() + "," + (int) p.getY() + "," + (int) p.getZ());
        Fx.tpPlayerTo(p, ow, CENTER.getX() + 0.5, CENTER.getY() + 1.0, CENTER.getZ() + 8.5);
        Fx.title(p, "DIMENSIONE 404", "Distruggi il Cuore per tornare");
        Fx.grant(p, "e404_dimensione");
        Progress.setFlag(p, "pocket.visited", true);
        for (int i = 0; i < 3; i++) {
            Minion m = Fx.spawn(ow, ModEntities.MINIONS.get(MinionType.DEMONE_MINORE).get(), CENTER.getX() + 4.5 - i * 4, CENTER.getY() + 1, CENTER.getZ() - 4.5);
            if (m != null) m.life = 6000;
        }
    }
    public static void leave(ServerPlayer p) {
        ServerLevel ow = p.level().getServer().overworld();
        int x = 0, y = 0, z = 0; boolean found = false;
        String ret = Store.get(p.getUUID(), "ret");
        if (ret != null) {
            String[] a = ret.split(",");
            try { x = Integer.parseInt(a[0]); y = Integer.parseInt(a[1]); z = Integer.parseInt(a[2]); found = true; } catch (Exception ignored) { }
            Store.put(p.getUUID(), "ret", null);
        }
        if (!found) { x = 0; z = 0; y = (int) Fx.groundY(ow, 0, 0); }
        Fx.tpPlayerTo(p, ow, x + 0.5, y + 1.0, z + 0.5);
        Fx.info(p, ChatFormatting.GREEN, "Sei tornato nel mondo normale.");
    }
    /** Controllo al secondo: se il Cuore non c'è più, il giocatore l'ha distrutto. */
    public static void poll(ServerPlayer p, ServerLevel lv) {
        if (lv.hasChunkAt(CENTER) && !lv.getBlockState(CENTER.above()).is(ModBlocks.CUORE_404.get())) heartBroken(p);
    }
    public static void heartBroken(ServerPlayer p) {
        Fx.title(p, "IL CUORE È SPEZZATO", "Entity 404 è più debole... ma non morto");
        Progress.addCtr(p, "heart", 1);
        Fx.grant(p, "e404_cuore");
        leave(p);
    }
    public static void build(ServerLevel ow) {
        for (int cx = -2; cx <= 2; cx++) for (int cz = -2; cz <= 2; cz++) ow.getChunk((CENTER.getX() >> 4) + cx, (CENTER.getZ() >> 4) + cz);
        for (int dx = -17; dx <= 17; dx++) for (int dz = -17; dz <= 17; dz++) {
            double d = Math.sqrt(dx * dx + dz * dz);
            if (d <= 16.5) { ow.setBlock(CENTER.offset(dx, -1, dz), ModBlocks.BLOCCO_ORGANICO.get().defaultBlockState(), 2); ow.setBlock(CENTER.offset(dx, -2, dz), Blocks.BEDROCK.defaultBlockState(), 2); }
            else if (d <= 17.5) for (int y = 0; y < 7; y++) ow.setBlock(CENTER.offset(dx, y, dz), ModBlocks.CUBO_VERDE.get().defaultBlockState(), 2);
        }
        for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) ow.setBlock(CENTER.offset(dx, 0, dz), ModBlocks.BLOCCO_ORGANICO.get().defaultBlockState(), 2);
        ow.setBlock(CENTER.above(), ModBlocks.CUORE_404.get().defaultBlockState(), 2);
    }
}
