package com.magialuama.horrorverse;

import java.util.Arrays;
import java.util.EnumSet;

/** Mostri del mod (generato da tools/gen.py). I comportamenti dipendono dai tratti. */
public enum MinionType {
    ZOMBIE_BIANCO("zombie_bianco", "Zombie dagli Occhi Bianchi", 0.6f, 1.95f, 36, 7f, 0.3, 1.0f, "frammento_occhio_bianco:0.15:1:1", Trait.CHASE),
    GUARDIANO_PALLIDO("guardiano_pallido", "Guardiano Pallido", 0.7f, 2.0f, 60, 8f, 0.22, 1.1f, "frammento_occhio_bianco:0.25:1:1", Trait.CHASE),
    CAVALIERE_FULMINE("cavaliere_fulmine", "Cavaliere del Fulmine", 0.6f, 1.95f, 50, 6f, 0.27, 1.0f, "cristallo_luce:0.2:1:1", Trait.CHASE, Trait.RANGED),
    SENTINELLA_END("sentinella_end", "Sentinella dell'End", 0.6f, 2.3f, 40, 6f, 0.25, 1.1f, "perla_rituale:0.02:1:1", Trait.CHASE, Trait.TELEPORT),
    IMITATORE_BIANCO("imitatore_bianco", "Imitatore Bianco", 0.6f, 1.95f, 30, 5f, 0.28, 1.0f, "", Trait.AMBUSH, Trait.CHASE),
    OMBRA_CUSTODE("ombra_custode", "Ombra del Custode", 0.6f, 1.95f, 24, 5f, 0.32, 1.0f, "", Trait.TELEPORT, Trait.SHY, Trait.CHASE),
    STATUA_VIVENTE("statua_vivente", "Statua Vivente", 0.7f, 2.0f, 120, 16f, 0.34, 1.05f, "cristallo_luce:0.3:1:1", Trait.STATUE),
    OCCHIO_ERRANTE("occhio_errante", "Occhio Errante", 0.5f, 0.9f, 14, 4f, 0.25, 0.5f, "", Trait.FLY, Trait.CHASE),
    OMBRA_DIVORATRICE("ombra_divoratrice", "Ombra Divoratrice", 0.6f, 1.95f, 40, 7f, 0.3, 1.0f, "", Trait.CHASE, Trait.SHY),
    CAVALIERE_OSCURO("cavaliere_oscuro", "Cavaliere Oscuro", 0.65f, 2.0f, 70, 9f, 0.26, 1.05f, "cristallo_luce:0.15:1:1", Trait.CHASE),
    CLONE_INCOMPLETO("clone_incompleto", "Clone Incompleto", 0.6f, 1.95f, 30, 5f, 0.3, 1.0f, "", Trait.CHASE),
    FRAMMENTO_ANIMA("frammento_anima", "Frammento d'Anima", 0.4f, 0.9f, 10, 0f, 0.22, 0.5f, "", Trait.FLY, Trait.CHASE, Trait.DRAIN),
    ZOMBIE_VERDE("zombie_verde", "Zombie Verde", 0.6f, 1.95f, 30, 5f, 0.3, 1.0f, "frammento_verde:0.35:1:2", Trait.CHASE),
    SCHELETRO_CORROTTO("scheletro_corrotto", "Scheletro Corrotto", 0.6f, 1.99f, 24, 4f, 0.28, 1.0f, "frammento_verde:0.35:1:2", Trait.RANGED, Trait.CHASE),
    CREEPER_INFETTO("creeper_infetto", "Creeper Infetto", 0.6f, 1.7f, 20, 0f, 0.32, 1.0f, "frammento_verde:0.5:1:2", Trait.EXPLODE, Trait.CHASE),
    TENTACOLO_VIVENTE("tentacolo_vivente", "Tentacolo Vivente", 0.7f, 2.4f, 50, 8f, 0.0, 1.2f, "frammento_verde:0.5:1:3", Trait.ROOTED),
    SENTINELLA_VERDE("sentinella_verde", "Sentinella Verde", 0.8f, 2.6f, 80, 10f, 0.0, 1.3f, "nucleo_corrotto:0.3:1:1", Trait.ROOTED, Trait.RANGED),
    DEMONE_MINORE("demone_minore", "Demone Minore", 0.6f, 1.95f, 90, 9f, 0.28, 1.0f, "frammento_verde:0.5:1:3", Trait.CHASE),
    DEMONE_MAGGIORE("demone_maggiore", "Demone Maggiore", 0.9f, 2.7f, 300, 14f, 0.27, 1.4f, "nucleo_corrotto:0.8:1:1", Trait.CHASE, Trait.SUMMON),
    CUCCIOLO_CORROTTO("cucciolo_corrotto", "Cucciolo Corrotto", 0.6f, 1.6f, 220, 10f, 0.3, 0.9f, "nucleo_corrotto:0.9:1:2", Trait.CHASE, Trait.DRAIN, Trait.SLOW),
    BESTIA_METEORICA("bestia_meteorica", "Bestia Meteorica", 1.0f, 2.6f, 260, 12f, 0.25, 1.6f, "nucleo_corrotto:0.7:1:1", Trait.FLY, Trait.RANGED),
    CLONE_IMPERFETTO("clone_imperfetto", "Clone Imperfetto", 0.6f, 1.95f, 40, 6f, 0.3, 1.0f, "frammento_verde:0.3:1:1", Trait.CHASE),
    CLONE_VENDICATIVO("clone_vendicativo", "Clone Vendicativo", 0.6f, 1.95f, 400, 13f, 0.3, 1.0f, "nucleo_corrotto:1.0:1:2", Trait.CHASE),
    GOLEM_RUNICO("golem_runico", "Golem Runico", 0.9f, 2.6f, 150, 12f, 0.2, 1.3f, "runa_antica:0.2:1:1", Trait.CHASE),
    SPETTRO_ILLUSORIO("spettro_illusorio", "Spettro Illusorio", 0.6f, 1.95f, 1, 0f, 0.3, 1.0f, "", Trait.ILLUSION, Trait.CHASE),
    GUARDIANO_ARCANO("guardiano_arcano", "Guardiano Arcano", 0.65f, 2.0f, 90, 8f, 0.24, 1.05f, "runa_antica:0.15:1:1", Trait.CHASE),
    CORVO_MAGO("corvo_mago", "Corvo del Mago", 0.4f, 0.7f, 6, 1f, 0.3, 0.4f, "frammento_spettrale:0.5:1:1", Trait.FLY, Trait.NEUTRAL),
    ELEMENTALE_VIOLA("elementale_viola", "Elementale Viola", 0.7f, 2.0f, 40, 7f, 0.26, 1.1f, "runa_antica:0.2:1:1", Trait.FLY, Trait.RANGED),
    CAVALIERE_RUNE("cavaliere_rune", "Cavaliere delle Rune", 0.65f, 2.0f, 80, 10f, 0.27, 1.05f, "runa_antica:0.2:1:1", Trait.CHASE),
    ECO_VIVENTE("eco_vivente", "Eco Vivente", 0.6f, 1.95f, 40, 5f, 0.3, 1.0f, "", Trait.CHASE),
    SENTINELLA_MECCANICA("sentinella_meccanica", "Sentinella Meccanica", 0.7f, 2.0f, 60, 6f, 0.0, 1.1f, "frammento_spettrale:0.3:1:1", Trait.ROOTED, Trait.RANGED),
    GOLEM_DIFESA("golem_difesa", "Golem da Difesa", 0.9f, 2.7f, 140, 12f, 0.22, 1.3f, "lingotto_spettrale:0.2:1:1", Trait.CHASE),
    CACCIATORE_CORAZZATO("cacciatore_corazzato", "Cacciatore Corazzato", 0.6f, 1.95f, 80, 8f, 0.3, 1.0f, "lingotto_spettrale:0.15:1:1", Trait.CHASE),
    DRONE_RICOGNIZIONE("drone_ricognizione", "Drone di Ricognizione", 0.4f, 0.7f, 10, 0f, 0.3, 0.4f, "", Trait.FLY, Trait.NEUTRAL),
    VIANDANTE_SENZA_VOLTO("viandante_senza_volto", "Viandante Senza Volto", 0.6f, 1.95f, 20, 0f, 0.25, 1.0f, "", Trait.SHY, Trait.NEUTRAL),
    CACCIATORE_NOTTURNO("cacciatore_notturno", "Cacciatore Notturno", 0.6f, 1.95f, 40, 7f, 0.33, 1.0f, "frammento_spettrale:0.3:1:1", Trait.CHASE),
    PREDATORE_SILENZIOSO("predatore_silenzioso", "Predatore Silenzioso", 0.6f, 1.95f, 50, 8f, 0.3, 1.0f, "", Trait.AMBUSH, Trait.SHY, Trait.CHASE),
    CAVALIERE_SPEZZATO("cavaliere_spezzato", "Cavaliere Spezzato", 0.65f, 2.0f, 60, 8f, 0.26, 1.0f, "lingotto_spettrale:0.1:1:1", Trait.CHASE),
    IL_MIETITORE("il_mietitore", "Il Mietitore", 0.7f, 2.1f, 200, 12f, 0.28, 1.15f, "falce_mietitore:0.5:1:1", Trait.CHASE, Trait.TELEPORT),
    REGINA_STATUE("regina_statue", "La Regina delle Statue", 0.8f, 2.3f, 260, 10f, 0.25, 1.2f, "cristallo_luce:1.0:2:4", Trait.CHASE, Trait.SUMMON),
    COLOSSO_RUNICO("colosso_runico", "Il Colosso Runico", 1.2f, 3.4f, 320, 14f, 0.18, 1.8f, "runa_antica:1.0:2:3", Trait.CHASE, Trait.RANGED);

    public enum Trait { CHASE, TELEPORT, STATUE, SHY, RANGED, EXPLODE, AMBUSH, ILLUSION, SUMMON, SLOW, FLY, NEUTRAL, ROOTED, DRAIN }
    public final String id, nameIt, drops;
    public final float w, h, dmg, scale;
    public final int hp;
    public final double speed;
    public final EnumSet<Trait> traits;
    MinionType(String id, String nameIt, float w, float h, int hp, float dmg, double speed, float scale, String drops, Trait... tr) {
        this.id = id; this.nameIt = nameIt; this.w = w; this.h = h; this.hp = hp; this.dmg = dmg; this.speed = speed; this.scale = scale; this.drops = drops;
        this.traits = tr.length == 0 ? EnumSet.noneOf(Trait.class) : EnumSet.copyOf(Arrays.asList(tr));
    }
}
