package com.magialuama.horrorverse;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;

@Mod(HorrorVerse.MODID)
public class HorrorVerse {
    public static final String MODID = "horrorverse";

    public HorrorVerse(IEventBus modBus, ModContainer container) {
        Reg.register(modBus);
        container.registerConfig(ModConfig.Type.STARTUP, Config.SPEC);
        modBus.addListener(HorrorVerse::attributes);
        NeoForge.EVENT_BUS.register(Events.class);
        NeoForge.EVENT_BUS.register(Director.class);
        NeoForge.EVENT_BUS.register(Cmd.class);
    }

    private static void attributes(EntityAttributeCreationEvent e) {
        for (Kind k : Kind.values()) e.put(ModEntities.of(k), HorrorBoss.attrs().build());
        for (MinionType t : MinionType.values()) e.put(ModEntities.MINIONS.get(t).get(), Minion.attrs(t).build());
    }
}
