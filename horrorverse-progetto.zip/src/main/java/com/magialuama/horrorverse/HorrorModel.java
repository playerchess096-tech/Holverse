package com.magialuama.horrorverse;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Modello umanoide con skin 64x64 (braccio e gamba sinistri separati). Variante "mago": cappello a punta e mantello. */
public class HorrorModel extends HumanoidModel<HorrorRenderState> {
    public HorrorModel(ModelPart root) { super(root); }

    public static LayerDefinition layer(boolean wizard) {
        MeshDefinition mesh = HumanoidModel.createMesh(CubeDeformation.NONE, 0.0F);
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("left_arm", CubeListBuilder.create().texOffs(32, 48).addBox(-1.0F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F), PartPose.offset(5.0F, 2.0F, 0.0F));
        root.addOrReplaceChild("left_leg", CubeListBuilder.create().texOffs(16, 48).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F), PartPose.offset(1.9F, 12.0F, 0.0F));
        if (wizard) {
            PartDefinition head = root.getChild("head");
            head.addOrReplaceChild("cappello_tesa", CubeListBuilder.create().texOffs(64, 0).addBox(-7.0F, -9.0F, -7.0F, 14.0F, 1.0F, 14.0F), PartPose.ZERO);
            head.addOrReplaceChild("cappello_1", CubeListBuilder.create().texOffs(64, 16).addBox(-4.0F, -13.0F, -4.0F, 8.0F, 4.0F, 8.0F), PartPose.ZERO);
            head.addOrReplaceChild("cappello_2", CubeListBuilder.create().texOffs(64, 29).addBox(-2.5F, -16.0F, -2.5F, 5.0F, 3.0F, 5.0F), PartPose.ZERO);
            head.addOrReplaceChild("cappello_3", CubeListBuilder.create().texOffs(64, 38).addBox(-1.5F, -19.0F, -0.5F, 3.0F, 3.0F, 3.0F), PartPose.ZERO);
            PartDefinition body = root.getChild("body");
            body.addOrReplaceChild("mantello", CubeListBuilder.create().texOffs(64, 46).addBox(-5.0F, 0.0F, 2.2F, 10.0F, 22.0F, 1.0F), PartPose.ZERO);
        }
        return LayerDefinition.create(mesh, wizard ? 128 : 64, wizard ? 128 : 64);
    }
}
