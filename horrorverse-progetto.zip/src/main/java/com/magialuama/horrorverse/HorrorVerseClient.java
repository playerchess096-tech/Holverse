package com.magialuama.horrorverse;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

@Mod(value = HorrorVerse.MODID, dist = Dist.CLIENT)
public class HorrorVerseClient {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(Fx.id("umanoide"), "main");
    public static final ModelLayerLocation LAYER_MAGO = new ModelLayerLocation(Fx.id("mago"), "main");

    public HorrorVerseClient(IEventBus modBus, ModContainer container) {
        modBus.addListener(HorrorVerseClient::layers);
        modBus.addListener(HorrorVerseClient::renderers);
    }
    private static void layers(EntityRenderersEvent.RegisterLayerDefinitions e) {
        e.registerLayerDefinition(LAYER, () -> HorrorModel.layer(false));
        e.registerLayerDefinition(LAYER_MAGO, () -> HorrorModel.layer(true));
    }
    private static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        for (Kind k : Kind.values()) {
            e.registerEntityRenderer(ModEntities.of(k), ctx -> new HRenderer<HorrorBoss>(ctx, k == Kind.MAGO ? LAYER_MAGO : LAYER,
                    b -> b.kind.texture(b.lvl(), b.variant())));
        }
        for (MinionType t : MinionType.values()) {
            e.registerEntityRenderer(ModEntities.MINIONS.get(t).get(), ctx -> new HRenderer<Minion>(ctx, LAYER,
                    m -> Fx.id("textures/entity/minion/" + t.id + ".png")));
        }
    }
}
