package com.magialuama.horrorverse;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

/** Sistema delle armi e delle vulnerabilità (Parte 9 del prompt). Tutte le regole numeriche sono qui. */
public final class Vuln {
    private Vuln() {}
    public enum W { ANTIVIRUS, QUARANTENA, OTHER }
    /** hitsA/hitsQ: colpi validi richiesti con la Spada Antivirus (livello 3) / Lama Quarantena (livello 6). */
    public record Rule(boolean allowed, int hitsA, int hitsQ, double minAtk, boolean needsWindow, boolean specialOnly) {}

    public static W weapon(ServerPlayer p) {
        ItemStack s = p.getMainHandItem();
        if (s.is(ModItems.LAMA_ANTIVIRUS.get())) return W.ANTIVIRUS;
        if (s.is(ModItems.LAMA_QUARANTENA.get())) return W.QUARANTENA;
        return W.OTHER;
    }

    public static Rule rule(HorrorBoss b) {
        int L = b.lvl();
        return switch (b.kind) {
            case CUSTODE -> switch (L) {
                case 1 -> new Rule(true, 1, 1, 0, false, false);
                case 3 -> new Rule(true, 2, 1, 7, false, false);
                case 4 -> new Rule(true, 3, 1, Config.CUSTODE_L4_MIN_ATTACK.get(), false, false);
                default -> new Rule(false, 0, 0, 0, false, false);          // L2: solo il contatto; L5: solo le perle
            };
            case CORROTTO -> switch (L) {
                case 1, 2 -> new Rule(false, 2, 1, 0, false, true);          // non attaccabile se non con le armi speciali (vedi README: contraddizione 1)
                case 3 -> new Rule(true, 3, 1, 7, true, false);
                case 4 -> new Rule(true, 1, 1, 7, true, false);
                default -> new Rule(true, 4, 2, 8, true, false);
            };
            case ENTITY404 -> switch (L) {
                case 3 -> new Rule(false, 4, 2, 0, true, true);
                case 4 -> new Rule(false, 3, 3, 0, true, true);
                case 6 -> new Rule(false, 12, 6, 0, true, true);
                case 7 -> new Rule(false, 20, 10, 0, b.a < 5, true);          // servono le 5 Statue del Destino
                default -> new Rule(false, 0, 0, 0, false, false);
            };
            case MAGO -> switch (L) {
                case 1 -> new Rule(true, 0, 0, 6, false, false);
                case 2 -> new Rule(true, 0, 0, 6, true, false);
                case 3 -> new Rule(b.a <= 0, 0, 0, 7, false, false);
                case 4 -> new Rule(b.a <= 0, 0, 0, Config.MAGO_L4_MIN_ATTACK.get(), false, false);
                default -> new Rule(false, 0, 0, 0, false, false);
            };
            case STEVE -> new Rule(true, 0, 0, 0, false, false);
            default -> new Rule(false, 0, 0, 0, false, false);
        };
    }

    private static void hint(ServerPlayer p, String s) {
        if (p != null && Fx.cd(p.getUUID(), "hint", p.tickCount, 40)) Fx.bar(p, s);
    }

    public static void boss(LivingIncomingDamageEvent e, HorrorBoss b) {
        Entity src = e.getSource().getEntity();
        ServerPlayer p = src instanceof ServerPlayer sp ? sp : null;
        if (b.mode == HorrorBoss.PRESENCE) { Brains.presenceHit(b, p, e); return; }
        if (b.mode == HorrorBoss.CHOICE || p == null) { e.setCanceled(true); return; }
        if (Fights.preHit(b, p, e)) return;
        Rule r = rule(b);
        W w = weapon(p);
        float max = b.getMaxHealth();
        boolean special = (w == W.ANTIVIRUS && r.hitsA() > 0) || (w == W.QUARANTENA && r.hitsQ() > 0);
        if (!r.allowed() && !(r.specialOnly() && special)) { e.setCanceled(true); hint(p, "Non puoi ferirlo così..."); return; }
        if (r.needsWindow() && !b.window) { e.setCanceled(true); hint(p, "È invulnerabile. Aspetta il segnale (particelle bianche)."); return; }
        float dmg;
        if (special) dmg = max / (w == W.ANTIVIRUS ? r.hitsA() : r.hitsQ());
        else {
            double atk = p.getAttributeValue(Attributes.ATTACK_DAMAGE);
            if (r.minAtk() > 0 && atk < r.minAtk()) { dmg = Math.max(1.0f, e.getAmount() * 0.2f); hint(p, "Arma troppo debole (attacco " + (int) atk + ", serve " + (int) r.minAtk() + ")"); }
            else dmg = Math.min(e.getAmount(), max * 0.10f);
        }
        if (b.tickCount - b.lastHit < 8) { e.setCanceled(true); return; }      // un colpo non si conta due volte
        b.lastHit = b.tickCount;
        if (special) b.hitCount++;
        if (b.kind == Kind.STEVE && b.c > b.fightTick) dmg *= 0.4f;             // scudo di Steve alzato
        Fights.onValidHit(b, p, w, special);
        if (b.getHealth() - dmg <= 1.0f) { e.setCanceled(true); b.defeat(p); return; }
        e.setAmount(dmg);
    }

    public static void minion(LivingIncomingDamageEvent e, Minion m) {
        Entity src = e.getSource().getEntity();
        ServerPlayer p = src instanceof ServerPlayer sp ? sp : null;
        ServerLevel lv = (ServerLevel) m.level();
        if (m.type.traits.contains(MinionType.Trait.ILLUSION)) { e.setCanceled(true); m.vanish(lv); return; }
        if (m.type.traits.contains(MinionType.Trait.STATUE)) {
            if (p == null || !p.getMainHandItem().is(ItemTags.PICKAXES)) { e.setCanceled(true); hint(p, "Solo un piccone può spezzare una statua."); return; }
            e.setAmount(m.getMaxHealth() * 0.34f);
            return;
        }
        if (p == null) return;
        int ha = 0, hq = 0;
        switch (m.type) {
            case ZOMBIE_BIANCO -> { ha = 2; hq = 1; }           // zombie del Custode
            case CLONE_VENDICATIVO -> { ha = 4; hq = 2; }       // clone di Entity 404
            default -> { }
        }
        W w = weapon(p);
        if (w == W.ANTIVIRUS && ha > 0) e.setAmount(m.getMaxHealth() / ha + 0.5f);
        else if (w == W.QUARANTENA && hq > 0) e.setAmount(m.getMaxHealth() / hq + 0.5f);
    }
}
