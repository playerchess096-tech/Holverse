package com.magialuama.horrorverse;

import java.util.Map;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAssets;

public final class Mats {
    private Mats() {}
    public static final ToolMaterial SPETTRALE = new ToolMaterial(BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 1800, 8.0f, 3.0f, 18,
            TagKey.create(Registries.ITEM, Fx.id("repairs_spettrale")));
    public static final ArmorMaterial ANTIVIRUS = new ArmorMaterial(37,
            Map.of(ArmorType.BOOTS, 3, ArmorType.LEGGINGS, 6, ArmorType.CHESTPLATE, 8, ArmorType.HELMET, 3),
            20, SoundEvents.ARMOR_EQUIP_NETHERITE, 3.0f, 0.1f,
            TagKey.<Item>create(Registries.ITEM, Fx.id("repairs_antivirus")),
            ResourceKey.create(EquipmentAssets.ROOT_ID, Fx.id("antivirus")));
}
