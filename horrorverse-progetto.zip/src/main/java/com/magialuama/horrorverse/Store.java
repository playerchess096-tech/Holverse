package com.magialuama.horrorverse;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.storage.LevelResource;

/** Salvataggio dei progressi in un file di testo nella cartella del mondo (horrorverse_data.txt). Non usa tag né NBT. */
public final class Store {
    private Store() {}
    private static final Map<UUID, Map<String, String>> P = new HashMap<>();
    private static final Map<UUID, Integer> BOSS = new HashMap<>();
    private static final Set<String> WORLD = new HashSet<>();
    private static MinecraftServer cur;
    private static Path file;
    private static boolean dirty;
    private static long lastSave;

    public static synchronized void ensure(MinecraftServer s) {
        if (s == null || s == cur) return;
        if (cur != null) flush(true);
        cur = s; P.clear(); BOSS.clear(); WORLD.clear(); dirty = false;
        try { file = s.getWorldPath(LevelResource.ROOT).resolve("horrorverse_data.txt"); } catch (Throwable t) { file = Path.of("horrorverse_data.txt"); }
        try {
            if (Files.exists(file)) for (String line : Files.readAllLines(file, StandardCharsets.UTF_8)) {
                String[] a = line.split("\t", 4);
                try {
                    if (a[0].equals("U") && a.length == 4) P.computeIfAbsent(UUID.fromString(a[1]), k -> new HashMap<>()).put(a[2], a[3]);
                    else if (a[0].equals("B") && a.length >= 3) BOSS.put(UUID.fromString(a[1]), Integer.parseInt(a[2]));
                    else if (a[0].equals("W") && a.length >= 2) WORLD.add(a[1]);
                } catch (RuntimeException ignored) { }
            }
        } catch (IOException ignored) { }
    }

    public static synchronized String get(UUID id, String key) { Map<String, String> m = P.get(id); return m == null ? null : m.get(key); }
    public static synchronized void put(UUID id, String key, String val) {
        Map<String, String> m = P.computeIfAbsent(id, k -> new HashMap<>());
        if (val == null) m.remove(key); else m.put(key, val);
        dirty = true;
    }
    public static synchronized void removeAll(UUID id) { P.remove(id); dirty = true; }
    public static synchronized int bossLevel(UUID id) { return BOSS.getOrDefault(id, 0); }
    public static synchronized void setBossLevel(UUID id, int l) { BOSS.put(id, l); dirty = true; }
    public static synchronized boolean worldHas(String k) { return WORLD.contains(k); }
    public static synchronized void worldAdd(String k) { if (WORLD.add(k)) dirty = true; }

    public static synchronized void flush(boolean force) {
        if (!dirty || file == null) return;
        long now = System.currentTimeMillis();
        if (!force && now - lastSave < 5000L) return;
        List<String> out = new ArrayList<>();
        for (Map.Entry<UUID, Map<String, String>> e : P.entrySet()) for (Map.Entry<String, String> k : e.getValue().entrySet()) out.add("U\t" + e.getKey() + "\t" + k.getKey() + "\t" + k.getValue());
        for (Map.Entry<UUID, Integer> e : BOSS.entrySet()) out.add("B\t" + e.getKey() + "\t" + e.getValue());
        for (String w : WORLD) out.add("W\t" + w);
        try { Files.write(file, out, StandardCharsets.UTF_8); dirty = false; lastSave = now; } catch (IOException ignored) { }
    }
}
