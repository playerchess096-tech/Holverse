package com.magialuama.horrorverse;

import java.util.*;
import net.minecraft.ChatFormatting;
import net.minecraft.advancements.AdvancementHolder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.Containers;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

/** Funzioni di utilità: tutte le chiamate "delicate" alle API di Minecraft passano da qui. */
public final class Fx {
    private Fx() {}
    public static final ParticleOptions GREEN = ParticleTypes.HAPPY_VILLAGER;
    private static final Map<String, Long> COOLDOWNS = new HashMap<>();

    public static Identifier id(String path) { return Identifier.fromNamespaceAndPath(HorrorVerse.MODID, path); }

    // ---------- messaggi
    public static void say(ServerPlayer p, Kind k, String text) {
        p.sendSystemMessage(Component.literal("<" + k.nameIt + "> ").withStyle(k.chat).append(Component.literal(text).withStyle(ChatFormatting.WHITE)));
    }
    public static void info(ServerPlayer p, ChatFormatting f, String text) { p.sendSystemMessage(Component.literal(text).withStyle(f)); }
    public static void bar(ServerPlayer p, String text) { p.sendSystemMessage(Component.literal(text), true); }
    public static void title(ServerPlayer p, String t, String sub) {
        p.connection.send(new ClientboundSetTitlesAnimationPacket(10, 60, 20));
        p.connection.send(new ClientboundSetSubtitleTextPacket(Component.literal(sub)));
        p.connection.send(new ClientboundSetTitleTextPacket(Component.literal(t)));
    }

    // ---------- suoni e particelle
    public static void sound(ServerLevel lv, double x, double y, double z, SoundEvent s, float vol, float pitch) {
        lv.playSound(null, x, y, z, s, SoundSource.HOSTILE, vol, pitch);
    }
    public static void soundTo(ServerPlayer p, SoundEvent s, float vol, float pitch) { ((ServerLevel) p.level()).playSound(null, p.getX(), p.getY(), p.getZ(), s, SoundSource.AMBIENT, vol, pitch); }
    public static void particles(ServerLevel lv, ParticleOptions o, double x, double y, double z, int n, double dx, double dy, double dz, double sp) {
        lv.sendParticles(o, x, y, z, n, dx, dy, dz, sp);
    }
    public static void beam(ServerLevel lv, Vec3 a, Vec3 b, ParticleOptions o) {
        Vec3 d = b.subtract(a); int n = (int) Math.max(2, d.length() * 2);
        for (int i = 0; i <= n; i++) { Vec3 q = a.add(d.scale(i / (double) n)); lv.sendParticles(o, q.x, q.y, q.z, 1, 0, 0, 0, 0); }
    }

    // ---------- entità
    public static <T extends Entity> T spawn(ServerLevel lv, EntityType<T> t, double x, double y, double z) {
        T e = t.create(lv, EntitySpawnReason.EVENT);
        if (e == null) return null;
        e.setPos(x, y, z);
        lv.addFreshEntity(e);
        return e;
    }
    public static void moveTo(Entity e, double x, double y, double z) {
        e.setPos(x, y, z); e.resetFallDistance();
        if (e instanceof Mob m) m.getNavigation().stop();
    }
    public static void tpPlayer(ServerPlayer p, double x, double y, double z) {
        p.teleportTo((ServerLevel) p.level(), x, y, z, Set.of(), p.getYRot(), p.getXRot(), true);
    }
    public static void bolt(ServerLevel lv, double x, double y, double z) {
        Entity e = vanillaType("lightning_bolt").create(lv, EntitySpawnReason.EVENT);
        if (!(e instanceof LightningBolt b)) return;
        b.setPos(x, y, z); b.setVisualOnly(true); lv.addFreshEntity(b);
    }
    public static void hurt(LivingEntity t, DamageSource s, float a) { t.hurt(s, a); }
    public static void explode(ServerLevel lv, Entity src, double x, double y, double z, float power) {
        lv.explode(src, x, y, z, power, Level.ExplosionInteraction.NONE);
    }
    /** Applica un effetto negativo del mod rispettando lo Scudo dell'Eden. */
    public static boolean afflict(ServerPlayer p, Holder<MobEffect> e, int ticks, int amp) {
        if (p.hasEffect(ModEffects.SCUDO_EDEN) && Config.EDEN_BLOCKS.get()) return false;
        return p.addEffect(new MobEffectInstance(e, ticks, amp, false, true));
    }
    public static boolean looking(ServerPlayer p, Entity e, double cos) {
        Vec3 look = p.getLookAngle().normalize();
        Vec3 to = e.getEyePosition().subtract(p.getEyePosition()).normalize();
        return look.dot(to) > cos && p.hasLineOfSight(e);
    }
    public static double groundY(ServerLevel lv, double x, double z) {
        return lv.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int) Math.floor(x), (int) Math.floor(z));
    }
    public static Vec3 ring(ServerLevel lv, Vec3 c, double rmin, double rmax) {
        double a = lv.getRandom().nextDouble() * Math.PI * 2, r = rmin + lv.getRandom().nextDouble() * (rmax - rmin);
        double x = c.x + Math.cos(a) * r, z = c.z + Math.sin(a) * r;
        return new Vec3(x, groundY(lv, x, z), z);
    }

    // ---------- oggetti
    public static void give(ServerPlayer p, ItemStack s) {
        if (s.isEmpty()) return;
        if (!p.getInventory().add(s)) Containers.dropItemStack((ServerLevel) p.level(), p.getX(), p.getY(), p.getZ(), s);
    }
    public static void mark(ItemStack s, String key) { CustomData.update(DataComponents.CUSTOM_DATA, s, t -> t.putBoolean(key, true)); }
    public static boolean marked(ItemStack s, String key) {
        if (s.isEmpty()) return false;
        CustomData d = s.get(DataComponents.CUSTOM_DATA);
        return d != null && d.contains(key);
    }
    public static void unmark(ItemStack s, String key) {
        if (!marked(s, key)) return;
        CustomData.update(DataComponents.CUSTOM_DATA, s, t -> t.remove(key));
        CustomData d = s.get(DataComponents.CUSTOM_DATA);
        if (d != null && d.isEmpty()) s.remove(DataComponents.CUSTOM_DATA);
    }
    /** Rimuove da un giocatore tutti i marcatori temporanei del mod (oggetti bloccati/fantasma). */
    public static void cleanItems(ServerPlayer p, String key) {
        for (int i = 0; i < 36; i++) { ItemStack s = p.getInventory().getItem(i); if (marked(s, key)) unmark(s, key); }
    }
    /** Purificazione: toglie la corruzione dagli oggetti e l'effetto Corruzione. */
    public static void purify(ServerPlayer p) {
        cleanItems(p, "hv_corrupt");
        p.removeEffect(ModEffects.CORRUZIONE);
        p.removeEffect(ModEffects.PIAGA);
    }
    public static void tpPlayerTo(ServerPlayer p, ServerLevel lv, double x, double y, double z) {
        p.teleportTo(lv, x, y, z, Set.of(), p.getYRot(), p.getXRot(), true);
    }
    public static void removeDecoys(ServerPlayer p) {
        for (int i = 0; i < 36; i++) { ItemStack s = p.getInventory().getItem(i); if (s.is(ModItems.OCCHIO_FANTASMA.get())) p.getInventory().setItem(i, ItemStack.EMPTY); }
    }

    // ---------- varie
    /** Cooldown semplice per chiave; ritorna true se l'azione è consentita. */
    public static boolean cd(UUID who, String key, long now, int ticks) {
        String k = who + key; Long last = COOLDOWNS.get(k);
        if (last != null && now - last < ticks) return false;
        COOLDOWNS.put(k, now); return true;
    }
    public static void grant(ServerPlayer p, String advId) {
        try {
            AdvancementHolder h = p.level().getServer().getAdvancements().get(id(advId));
            if (h != null) p.getAdvancements().award(h, "x");
        } catch (Throwable ignored) { }
    }
    /** Notte approssimata: all'aperto e con poca luce del cielo. */
    public static boolean isNight(ServerLevel lv, BlockPos pos) { return lv.canSeeSky(pos) && lv.getMaxLocalRawBrightness(pos) < 8; }
    public static EntityType<?> vanillaType(String id) { return BuiltInRegistries.ENTITY_TYPE.getValue(Identifier.withDefaultNamespace(id)); }
    public static boolean typeIs(Entity e, String id) { return BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).getPath().equals(id); }
}
