package com.magialuama.horrorverse;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredItem;

public final class ModBlocks {
    private ModBlocks() {}
    public static final DeferredBlock<Block> BLOCCO_OSCURO = block("blocco_oscuro", BlockBehaviour.Properties.of().strength(2.0f, 6.0f).sound(SoundType.DEEPSLATE));
    public static final DeferredBlock<Block> CUBO_VERDE = block("cubo_verde", BlockBehaviour.Properties.of().strength(-1.0f, 3600000.0f).sound(SoundType.AMETHYST).lightLevel(s -> 9));
    public static final DeferredBlock<Block> RUNA_PILASTRO = block("runa_pilastro", BlockBehaviour.Properties.of().strength(4.0f, 12.0f).sound(SoundType.STONE).lightLevel(s -> 8));
    public static final DeferredBlock<Block> GENERATORE_ARCANO = block("generatore_arcano", BlockBehaviour.Properties.of().strength(4.0f, 12.0f).sound(SoundType.AMETHYST).lightLevel(s -> 10));
    public static final DeferredBlock<Block> PIEDISTALLO_BASTONE = block("piedistallo_bastone", BlockBehaviour.Properties.of().strength(5.0f, 20.0f).sound(SoundType.STONE).lightLevel(s -> 12));
    public static final DeferredBlock<Block> STATUA_DESTINO = block("statua_destino", BlockBehaviour.Properties.of().strength(5.0f, 30.0f).requiresCorrectToolForDrops().sound(SoundType.STONE).lightLevel(s -> 6));
    public static final DeferredBlock<Block> CUORE_404 = block("cuore_404", BlockBehaviour.Properties.of().strength(8.0f, 100.0f).sound(SoundType.SLIME_BLOCK).lightLevel(s -> 15));
    public static final DeferredBlock<Block> BLOCCO_ORGANICO = block("blocco_organico", BlockBehaviour.Properties.of().strength(1.0f, 3.0f).sound(SoundType.SLIME_BLOCK));
    public static final DeferredBlock<Block> MINERALE_SPETTRALE = block("minerale_spettrale", BlockBehaviour.Properties.of().strength(3.0f, 3.0f).requiresCorrectToolForDrops().sound(SoundType.STONE));
    public static final DeferredBlock<Block> PIETRA_RITUALE = block("pietra_rituale", BlockBehaviour.Properties.of().strength(2.0f, 8.0f).sound(SoundType.STONE));
    public static final DeferredBlock<Block> TRACCIA_OSSERVATORE = block("traccia_osservatore", BlockBehaviour.Properties.of().strength(0.5f, 1.0f).sound(SoundType.SCULK).lightLevel(s -> 4));
    public static final DeferredBlock<Block> OCCHIO_OSSERVATORE = block("occhio_osservatore", BlockBehaviour.Properties.of().strength(1.0f, 1.0f).sound(SoundType.SCULK).lightLevel(s -> 15));
    private static DeferredBlock<Block> block(String id, BlockBehaviour.Properties p) {
        DeferredBlock<Block> b = Reg.BLOCKS.registerSimpleBlock(id, () -> p);
        DeferredItem<BlockItem> i = Reg.ITEMS.registerSimpleBlockItem(id, b);
        Reg.TAB_ITEMS.add(i); Reg.BY_ID.put(id, i);
        return b;
    }
    public static void init() { }
}
