package com.magialuama.horrorverse;

import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Mostro generico: il comportamento deriva dai tratti di {@link MinionType}. */
public class Minion extends PathfinderMob {
    public final MinionType type;
    public UUID owner;
    public int life = 24000, shy, orphan;
    public boolean revealed;

    public Minion(EntityType<? extends PathfinderMob> t, Level level, MinionType type) {
        super(t, level);
        this.type = type;
    }
    public static AttributeSupplier.Builder attrs(MinionType t) {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, t.hp).add(Attributes.MOVEMENT_SPEED, Math.max(0.01, t.speed))
                .add(Attributes.ATTACK_DAMAGE, Math.max(0.0, t.dmg)).add(Attributes.FOLLOW_RANGE, 40.0).add(Attributes.SCALE, t.scale)
                .add(Attributes.KNOCKBACK_RESISTANCE, t.hp > 100 ? 0.6 : 0.0);
    }
    private boolean has(MinionType.Trait tr) { return type.traits.contains(tr); }

    @Override protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        if (!has(MinionType.Trait.ROOTED) && !has(MinionType.Trait.FLY)) goalSelector.addGoal(7, new WaterAvoidingRandomStrollGoal(this, 0.6D));
        goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 10.0F));
        goalSelector.addGoal(9, new RandomLookAroundGoal(this));
    }
    @Override public boolean removeWhenFarAway(double dist) { return owner == null && !has(MinionType.Trait.NEUTRAL) ? super.removeWhenFarAway(dist) : false; }

    @Override public void tick() {
        super.tick();
        if (level().isClientSide()) return;
        ServerLevel lv = (ServerLevel) level();
        if (--life <= 0) { discard(); return; }
        if (owner != null && tickCount % 100 == 0) { orphan = lv.getEntity(owner) == null ? orphan + 1 : 0; if (orphan > 3) { discard(); return; } }
        Player near = lv.getNearestPlayer(getX(), getY(), getZ(), 40.0, e -> !e.isSpectator());
        if (!(near instanceof ServerPlayer p)) return;
        double d2 = distanceToSqr(p);
        boolean fly = has(MinionType.Trait.FLY);
        if (fly) setNoGravity(true);

        if (has(MinionType.Trait.NEUTRAL)) {            // corvi e droni: girano attorno al giocatore senza attaccare
            if (fly && tickCount % 2 == 0) {
                Vec3 to = p.position().add(Math.cos(tickCount / 20.0) * 3.0, 2.5, Math.sin(tickCount / 20.0) * 3.0).subtract(position());
                setDeltaMovement(to.length() > 0.5 ? to.normalize().scale(type.speed) : Vec3.ZERO);
            }
            if (has(MinionType.Trait.SHY) && Fx.looking(p, this, 0.97) && ++shy > 60) vanish(lv);
            return;
        }
        if (has(MinionType.Trait.AMBUSH) && !revealed) {  // resta fermo e invisibile finché il giocatore non è vicino
            setInvisible(true); getNavigation().stop();
            if (d2 < 36.0) { revealed = true; setInvisible(false); Fx.particles(lv, ParticleTypes.SMOKE, getX(), getY() + 1, getZ(), 20, 0.3, 0.6, 0.3, 0.05); }
            return;
        }
        if (has(MinionType.Trait.SHY)) {
            if (Fx.looking(p, this, 0.97)) { if (++shy > 45) { vanish(lv); return; } } else if (shy > 0) shy--;
        }
        if (has(MinionType.Trait.STATUE) && Fx.looking(p, this, 0.5)) {  // si muove solo quando non è osservata
            getNavigation().stop(); setDeltaMovement(0.0, getDeltaMovement().y, 0.0); return;
        }
        if (has(MinionType.Trait.TELEPORT) && tickCount % 90 == 0 && d2 > 25.0) {
            Vec3 v = Fx.ring(lv, p.position(), 3.0, 5.0); Fx.moveTo(this, v.x, v.y, v.z);
            Fx.particles(lv, ParticleTypes.PORTAL, v.x, v.y + 1, v.z, 20, 0.3, 0.6, 0.3, 0.2);
        }
        if (has(MinionType.Trait.ILLUSION) && tickCount > 1200) { vanish(lv); return; }

        // movimento
        if (fly) {
            Vec3 to = p.getEyePosition().subtract(position());
            setDeltaMovement(to.length() > (has(MinionType.Trait.RANGED) ? 9.0 : 1.5) ? to.normalize().scale(type.speed * 1.4) : Vec3.ZERO);
            lookAt(net.minecraft.commands.arguments.EntityAnchorArgument.Anchor.EYES, p.getEyePosition());
        } else if (!has(MinionType.Trait.ROOTED)) {
            getLookControl().setLookAt(p, 30.0f, 30.0f);
            if (tickCount % 8 == 0) getNavigation().moveTo(p, has(MinionType.Trait.STATUE) ? 1.7 : 1.1);
        } else getLookControl().setLookAt(p, 30.0f, 30.0f);

        // attacchi
        if (type.dmg > 0 && d2 <= (has(MinionType.Trait.ROOTED) ? 16.0 : 5.0) && tickCount % 20 == 0) {
            float dmg = (float) getAttributeValue(Attributes.ATTACK_DAMAGE) * Config.DAMAGE_MULT.get().floatValue();
            if (has(MinionType.Trait.STATUE) && p.hasEffect(ModEffects.SCUDO_EDEN)) dmg *= 0.8f;
            Fx.hurt(p, damageSources().mobAttack(this), dmg);
            if (has(MinionType.Trait.SLOW)) Fx.afflict(p, MobEffects.SLOWNESS, 80, 1);
            if (has(MinionType.Trait.DRAIN)) heal(dmg * 0.5f);
        }
        if (has(MinionType.Trait.RANGED) && tickCount % 60 == 0 && d2 < 576.0 && hasLineOfSight(p)) {
            Fx.beam(lv, getEyePosition(), p.getEyePosition().add(0, -0.3, 0), type.id.contains("verde") || type.id.contains("corrotto") ? Fx.GREEN : ParticleTypes.ELECTRIC_SPARK);
            Fx.hurt(p, lv.damageSources().magic(), Math.max(2.0f, type.dmg * 0.6f) * Config.DAMAGE_MULT.get().floatValue());
        }
        if (has(MinionType.Trait.EXPLODE) && d2 < 6.0) {
            Fx.explode(lv, this, getX(), getY(), getZ(), 1.6f);
            Fx.afflict(p, MobEffects.POISON, 100, 0);
            discard();
        }
        if (has(MinionType.Trait.SUMMON) && tickCount % 300 == 0 && owner != null) {
            for (int i = 0; i < 2; i++) {
                Vec3 v = Fx.ring(lv, position(), 2.0, 4.0);
                Minion m = Fx.spawn(lv, ModEntities.MINIONS.get(type.id.equals("regina_statue") ? MinionType.STATUA_VIVENTE : MinionType.DEMONE_MINORE).get(), v.x, v.y, v.z);
                if (m != null) { m.owner = owner; m.life = 3000; }
            }
        }
    }
    public void vanish(ServerLevel lv) {
        Fx.particles(lv, ParticleTypes.SMOKE, getX(), getY() + 1, getZ(), 25, 0.3, 0.7, 0.3, 0.04);
        discard();
    }
}
