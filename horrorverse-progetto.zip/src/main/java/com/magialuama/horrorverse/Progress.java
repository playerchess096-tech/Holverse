package com.magialuama.horrorverse;

import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

/** Progressi del giocatore (livelli superati, flag, contatori, capitolo) salvati tramite {@link Store}. */
public final class Progress {
    private Progress() {}

    private static UUID id(Player p) { Store.ensure(p.level().getServer()); return p.getUUID(); }
    private static int num(Player p, String key) {
        String s = Store.get(id(p), key);
        if (s == null) return 0;
        try { return Integer.parseInt(s); } catch (NumberFormatException e) { return 0; }
    }
    private static void put(Player p, String key, int v) { Store.put(id(p), key, v == 0 ? null : String.valueOf(v)); }

    public static int level(Player p, Kind k) { return num(p, "lv." + k.id); }
    public static void setLevel(Player p, Kind k, int lv) { if (lv > level(p, k)) put(p, "lv." + k.id, lv); }
    public static void resetLevel(Player p, Kind k, int lv) { put(p, "lv." + k.id, lv); }

    public static boolean flag(Player p, String f) { return "1".equals(Store.get(id(p), "f." + f)); }
    public static void setFlag(Player p, String f, boolean on) { Store.put(id(p), "f." + f, on ? "1" : null); }

    public static int ctr(Player p, String key) { return num(p, "c." + key); }
    public static void setCtr(Player p, String key, int v) { put(p, "c." + key, v); }
    public static int addCtr(Player p, String key, int d) { int v = ctr(p, key) + d; setCtr(p, key, v); return v; }

    public static int chapter(Player p) { return Math.max(1, ctr(p, "chapter")); }
    public static int minutes(Player p) { return ctr(p, "min"); }

    /** Capitolo narrativo: 1 Osservatore+Steve, 2 Custode, 3 Uomo Magico, 4 Corrotto, 5 Entity 404. */
    public static void updateChapter(ServerPlayer p) {
        int ch = chapter(p); double m = minutes(p) * Config.CHAPTER_SPEED.get();
        int target = ch;
        if (ch < 2 && m >= 20) target = 2;
        if (ch < 3 && m >= 60 && (level(p, Kind.CUSTODE) >= 1 || m >= 150)) target = Math.max(target, 3);
        if (ch < 4 && m >= 100 && (level(p, Kind.MAGO) >= 1 || m >= 250)) target = Math.max(target, 4);
        if (ch < 5 && m >= 160 && (level(p, Kind.CORROTTO) >= 2 || m >= 400)) target = Math.max(target, 5);
        if (target > ch) {
            setCtr(p, "chapter", target);
            String[] n = {"", "", "Il Custode dagli Occhi Bianchi comincia a farsi vedere.", "Rune e libri strani: l'Uomo Magico è vicino.",
                    "Un viaggiatore gentile da un altro universo si avvicina.", "Qualcosa di verde corrompe i messaggi. Entity 404 è vicino."};
            Fx.info(p, net.minecraft.ChatFormatting.DARK_GRAY, "— " + n[Math.min(target, 5)] + " —");
        }
    }

    public static void wipe(Player p) { Store.removeAll(id(p)); }
}
