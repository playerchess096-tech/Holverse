# -*- coding: utf-8 -*-
"""Sintesi dei suoni e delle musiche (numpy/scipy) e codifica OGG Vorbis con ffmpeg."""
import os, subprocess, sys, wave
import numpy as np
from scipy import signal

SR = 44100
OUT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src/main/resources/assets/horrorverse/sounds'))
os.makedirs(OUT, exist_ok=True)

def tt(d): return np.arange(int(d * SR)) / SR
def lp(x, f, o=2): b, a = signal.butter(o, min(f, SR / 2 - 100) / (SR / 2), 'low'); return signal.lfilter(b, a, x)
def hp(x, f, o=2): b, a = signal.butter(o, f / (SR / 2), 'high'); return signal.lfilter(b, a, x)
def bp(x, f0, f1, o=2): b, a = signal.butter(o, [f0 / (SR / 2), min(f1, SR / 2 - 100) / (SR / 2)], 'band'); return signal.lfilter(b, a, x)
def noise(n, rng): return rng.standard_normal(n)
def fade(x, a=0.02, r=0.05):
    n = len(x); na, nr = max(1, int(a * SR)), max(1, int(r * SR)); e = np.ones(n); e[:na] = np.linspace(0, 1, na); e[-nr:] = np.linspace(1, 0, nr); return x * e
def norm(x, peak=0.85): m = np.max(np.abs(x)) + 1e-9; return x / m * peak
def pluck(f, d, dec=0.4, kind='sine'):
    t = tt(d); ph = 2 * np.pi * f * t
    y = np.sin(ph) + (0.35 * np.sin(2 * ph) + 0.15 * np.sin(3 * ph) if kind != 'pure' else 0)
    return y * np.exp(-t / dec) * np.minimum(1, t / 0.005)
def bell(f, d, dec=1.5):
    t = tt(d); y = 0
    for r, g in ((1, 1), (2.76, 0.6), (5.4, 0.35), (8.93, 0.2), (1.5, 0.3)): y = y + g * np.sin(2 * np.pi * f * r * t) * np.exp(-t / (dec / (0.6 + 0.4 * r)))
    return y * np.minimum(1, t / 0.003)
def add(buf, x, t0, g=1.0):
    i = int(t0 * SR)
    if i >= len(buf): return
    j = min(len(buf), i + len(x)); buf[i:j] += x[:j - i] * g
def reverb(x, secs=1.6, wet=0.3, seed=1):
    r = np.random.default_rng(seed); n = int(secs * SR); ir = r.standard_normal(n) * np.exp(-np.arange(n) / (secs * SR / 4.5)); ir[0] = 0
    y = signal.fftconvolve(x, ir)[:len(x)]; y = y / (np.max(np.abs(y)) + 1e-9) * (np.max(np.abs(x)) + 1e-9)
    return x * (1 - wet) + y * wet
def save(name, x, stereo=False, q=4):
    if stereo and x.ndim == 1: x = np.stack([x, x], 1)
    if not stereo and x.ndim == 2: x = x.mean(1)
    x = np.clip(x, -1, 1); pcm = (x * 32767).astype('<i2')
    wav = '/tmp/_hv.wav'
    with wave.open(wav, 'wb') as w:
        w.setnchannels(2 if stereo else 1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', wav, '-c:a', 'libvorbis', '-q:a', str(q), os.path.join(OUT, name + '.ogg')], check=True)

# ------------------------------------------------------------------ effetti
def s_heartbeat(r):
    x = np.zeros(int(4 * SR))
    for b in range(4):
        for off, g in ((0.0, 1.0), (0.3, 0.7)):
            t = tt(0.25); add(x, np.sin(2 * np.pi * (58 - 25 * t / 0.25) * t) * np.exp(-t / 0.07), b + off, g)
    return norm(lp(x, 220))
def s_footsteps(r):
    x = np.zeros(int(5 * SR)); t0 = 0.2
    for i in range(7):
        t = tt(0.16); add(x, lp(noise(len(t), r), 500 + 200 * (i % 2)) * np.exp(-t / 0.05), t0, 1.0 - 0.1 * (i % 2)); t0 += 0.55 + r.random() * 0.25
    return norm(x)
def s_whisper(r, d=4.0, c=2200):
    n = int(d * SR); w = bp(noise(n, r), c * 0.5, c * 2.4)
    t = tt(d); m = np.clip(np.sin(2 * np.pi * (2.2 + r.random()) * t + r.random() * 6) * np.sin(2 * np.pi * 0.7 * t), 0, 1) ** 1.5
    return fade(norm(reverb(w * m, 1.2, 0.4)), 0.2, 0.4)
def s_drone(r, d=20.0, f=55.0):
    t = tt(d); x = 0
    for k, g in ((1, 1), (1.5, 0.5), (2, 0.4), (3.01, 0.15)): x = x + g * np.sin(2 * np.pi * f * k * t + 0.4 * np.sin(2 * np.pi * 0.13 * k * t))
    x = x * (0.7 + 0.3 * np.sin(2 * np.pi * 0.09 * t)); return fade(norm(lp(x, 900)), 2.0, 3.0)
def s_creak(r):
    d = 2.6; t = tt(d); f = 210 - 110 * (t / d) ** 0.7 + 8 * np.sin(2 * np.pi * 9 * t)
    x = signal.sawtooth(2 * np.pi * np.cumsum(f) / SR); x = bp(x, 300, 1800); return fade(norm(x * np.sin(np.pi * t / d) ** 0.6), 0.05, 0.3)
def s_thunder(r):
    d = 6.0; n = int(d * SR); x = lp(np.cumsum(noise(n, r)) / 300.0, 160) + lp(noise(n, r), 400) * 0.6; t = tt(d)
    e = np.minimum(1, t / 0.4) * np.exp(-t / 1.9) + 0.6 * np.exp(-((t - 2.5) ** 2) / 0.25); return fade(norm(x * e), 0.05, 0.5)
def s_jumpscare(r):
    d = 2.5; t = tt(d); f = 500 + 1600 * np.minimum(1, t / 0.6); x = signal.sawtooth(2 * np.pi * np.cumsum(f + 300 * np.sin(2 * np.pi * 40 * t)) / SR)
    x = x * 0.5 + noise(len(t), r) * 0.5; boom = np.sin(2 * np.pi * (70 - 30 * t) * t) * 1.5
    return fade(norm((x * np.exp(-t / 0.9) + boom * np.exp(-t / 0.6))), 0.003, 0.2, ) * 1.0
def s_glitch(r):
    n = int(2 * SR); x = np.zeros(n); t0 = 0
    while t0 < 1.9:
        L = int((0.02 + r.random() * 0.08) * SR); seg = np.sign(np.sin(2 * np.pi * (200 + r.random() * 2500) * (np.arange(L) / SR))) * 0.5 + noise(L, r) * 0.15
        for rep in range(r.integers(1, 5)): add(x, seg, t0 + rep * L / SR); 
        t0 += L / SR * (1 + r.random() * 4)
    return norm(np.round(x * 6) / 6)
def s_static(r): n = int(1.5 * SR); t = tt(1.5); return fade(norm(noise(n, r) * (np.sin(2 * np.pi * 11 * t) > -0.2)), 0.01, 0.3)
def s_bell(r): return fade(norm(bell(110, 5.0, 2.2)), 0.002, 0.8)
def s_chime(r):
    x = np.zeros(int(3 * SR))
    for i, f in enumerate((523, 659, 784, 1046)): add(x, bell(f, 2.0, 1.0), i * 0.18, 0.7)
    return fade(norm(reverb(x, 1.4, 0.35)), 0.002, 0.6)
def s_cast(r):
    d = 1.5; t = tt(d); x = np.sin(2 * np.pi * np.cumsum(300 + 1200 * (t / d) ** 2) / SR) * np.sin(np.pi * t / d) + hp(noise(len(t), r), 4000) * 0.2 * (t / d)
    return fade(norm(x), 0.01, 0.2)
def s_blip(r): t = tt(1.0); return fade(norm(np.sin(2 * np.pi * np.cumsum(1400 * np.exp(-t * 7) + 90) / SR) * np.exp(-t / 0.25) + lp(noise(len(t), r), 3000) * 0.15 * np.exp(-t / 0.1)), 0.002, 0.1)
def s_grind(r):
    d = 2.0; n = int(d * SR); t = tt(d); x = lp(noise(n, r), 380) * (0.5 + 0.5 * np.sin(2 * np.pi * 6 * t)); return fade(norm(x), 0.05, 0.4)
def s_victory(r):
    x = np.zeros(int(6 * SR))
    for i, f in enumerate((261.6, 329.6, 392.0, 523.3, 659.3)): add(x, bell(f, 3.0, 1.8), i * 0.28, 0.8)
    return fade(norm(reverb(x, 1.8, 0.35)), 0.002, 1.0)
def s_defeat(r):
    x = np.zeros(int(6 * SR))
    for i, f in enumerate((196, 185, 164.8, 130.8)):
        add(x, bell(f, 3.4, 2.0), i * 0.7, 0.8); add(x, pluck(f / 2, 3.0, 1.2), i * 0.7, 0.32)
    return fade(norm(reverb(x, 2.0, 0.4)), 0.002, 1.2)
def s_ambient(r, d=60.0, f=49.0, crick=False):
    n = int(d * SR); t = tt(d); x = np.zeros(n)
    for k, g in ((1, 1), (1.498, 0.5), (2.0, 0.3), (2.52, 0.2)): x += g * np.sin(2 * np.pi * f * k * t + 2 * np.sin(2 * np.pi * (0.03 + 0.01 * k) * t))
    x *= 0.6 + 0.4 * np.sin(2 * np.pi * 0.05 * t); x = lp(x, 700) * 0.7
    wind = bp(noise(n, r), 150, 700) * (0.5 + 0.5 * np.sin(2 * np.pi * 0.07 * t + 1)) * 0.25
    for _ in range(int(d / 6)): add(x, bell(r.choice([220, 261, 311, 392]) * 0.5, 4.0, 2.5), r.random() * (d - 4), 0.08)
    if crick:
        for _ in range(int(d * 0.8)): add(x, np.sin(2 * np.pi * 4500 * tt(0.03)) * np.exp(-tt(0.03) / 0.01), r.random() * d, 0.04)
    return fade(norm(reverb(x + wind, 2.2, 0.3), 0.7), 3.0, 4.0)

# ------------------------------------------------------------------ temi dei boss (stereo)
SCALES = {'min': [0, 2, 3, 5, 7, 8, 10], 'phr': [0, 1, 3, 5, 7, 8, 10], 'dim': [0, 2, 3, 5, 6, 8, 9, 11], 'whole': [0, 2, 4, 6, 8, 10], 'dor': [0, 2, 3, 5, 7, 9, 10]}
def theme(seed, root, scale, bpm, d=80.0, kick=True, arp=True, dark=1.0):
    r = np.random.default_rng(seed); N = int(d * SR); L = np.zeros(N); R = np.zeros(N); beat = 60.0 / bpm; sc = SCALES[scale]
    def nf(deg, octv=0): return root * 2 ** ((sc[deg % len(sc)] + 12 * (deg // len(sc)) + 12 * octv) / 12)
    def pan(x, t0, p, g=1.0): add(L, x, t0, g * (1 - p)); add(R, x, t0, g * p)
    ck = 0; clen = beat * 8
    while ck * clen < d:
        deg = int(r.choice([0, 0, 2, 3, 4, 5])); t0 = ck * clen
        for i in (0, 2, 4):
            f = nf(deg + i, 0); tc = tt(clen + 1.5)
            for side, det in ((0, 0.997), (1, 1.003)):
                x = signal.sawtooth(2 * np.pi * f * det * tc + 0.5 * np.sin(2 * np.pi * 0.2 * tc)) * 0.2
                x = lp(x, 650 + 500 * (1 - dark)) * np.minimum(1, tc / 2.0) * np.minimum(1, (tc[-1] - tc) / 1.5)
                pan(x, t0, side, 0.55)
        ck += 1
    nb = int(d / beat)
    for b in range(nb):
        t0 = b * beat
        if kick and b % 2 == 0 and b > 8:
            t = tt(0.3); pan(np.sin(2 * np.pi * (80 * np.exp(-t * 12) + 38) * t) * np.exp(-t / 0.12), t0, 0.5, 0.9)
        if b % 4 == 2 and b > 24: pan(lp(hp(noise(int(0.2 * SR), r), 900), 7000) * np.exp(-tt(0.2) / 0.05), t0, 0.5, 0.35)
        if b % 2 == 1 or b % 4 == 0:
            f = nf(0, -2) if (b // 4) % 2 == 0 else nf(3, -2); t = tt(beat * 0.9); pan(np.sin(2 * np.pi * f * t) * np.exp(-t / 0.35) * 0.8, t0, 0.5, 0.6)
        if arp and b > 16 and r.random() < 0.38:
            f = nf(int(r.integers(0, 10)), 1); pan(pluck(f, 1.8, 0.45) * 0.4, t0 + (0.5 * beat if r.random() < 0.4 else 0), float(r.random()), 0.55)
        if b % 32 == 16:
            t = tt(beat * 8); w = bp(noise(len(t), r), 300, 5000) * (t / t[-1]) ** 2; pan(w * 0.5, t0, 0.5, 0.5)
    if dark > 0.5:
        for _ in range(int(d / 9)): pan(bell(nf(int(r.integers(0, 5)), 1), 5.0, 2.5) * 0.3, r.random() * (d - 5), float(r.random()), 0.5)
    X = np.stack([L, R], 1)
    X[:, 0] = reverb(X[:, 0], 2.0, 0.28, seed); X[:, 1] = reverb(X[:, 1], 2.0, 0.28, seed + 1)
    X = X / (np.max(np.abs(X)) + 1e-9) * 0.8
    return fade(X[:, 0], 1.5, 4.0), fade(X[:, 1], 1.5, 4.0)

def main(only=None):
    r = np.random.default_rng(2026)
    sfx = {'heartbeat': s_heartbeat, 'footsteps': s_footsteps, 'whisper_a': lambda r: s_whisper(r, 4, 2000), 'whisper_b': lambda r: s_whisper(r, 5, 2800), 'whisper_c': lambda r: s_whisper(r, 3.5, 1600),
           'door_creak': s_creak, 'thunder_far': s_thunder, 'jumpscare': s_jumpscare, 'glitch': s_glitch, 'static_burst': s_static, 'bell_toll': s_bell, 'rune_chime': s_chime,
           'magic_cast': s_cast, 'teleport_blip': s_blip, 'statue_grind': s_grind, 'victory_sting': s_victory, 'defeat_sting': s_defeat, 'drone_low': lambda r: s_drone(r, 20, 55)}
    for k, f in sfx.items():
        if only and k not in only: continue
        save(k, f(np.random.default_rng(sum(map(ord, k)) * 7919)), False, 4); print('sfx', k, flush=True)
    for k, (dd, ff, ck) in {'ambient_night_a': (60, 49, False), 'ambient_night_b': (60, 55, True)}.items():
        if only and k not in only: continue
        a = s_ambient(np.random.default_rng(len(k)), dd, ff, ck); save(k, np.stack([a, np.roll(a, 900)], 1), True, 4); print('amb', k, flush=True)
    th = {'theme_custode': (11, 55.0, 'min', 62, 90.0, 1.0), 'theme_corrotto': (12, 49.0, 'phr', 70, 90.0, 1.0), 'theme_404': (13, 41.2, 'dim', 96, 100.0, 1.0),
          'theme_mago': (14, 58.3, 'dor', 76, 90.0, 0.6), 'theme_steve': (15, 65.4, 'min', 90, 90.0, 0.4), 'theme_osservatore': (16, 46.2, 'whole', 52, 90.0, 1.0)}
    for k, (seed, root, sc, bpm, dur, dark) in th.items():
        if only and k not in only: continue
        l, rr = theme(seed, root, sc, bpm, dur, kick=(k != 'theme_osservatore'), arp=(k != 'theme_404' or True), dark=dark); save(k, np.stack([l, rr], 1), True, 4); print('theme', k, flush=True)
    total = sum(os.path.getsize(os.path.join(OUT, f)) for f in os.listdir(OUT)); print('TOTALE audio: %.2f MB' % (total / 1e6))

if __name__ == '__main__':
    main(sys.argv[1:] or None)
