# -*- coding: utf-8 -*-
"""Texture procedurali: icone, blocchi, effetti, skin dei mostri, armature."""
import random, hashlib
from PIL import Image

def hexc(h): h = h.lstrip('#'); return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))
def sh(c, f): return tuple(max(0, min(255, int(v * f))) for v in c)
def jit(c, r, amt): return tuple(max(0, min(255, v + r.randint(-amt, amt))) for v in c)
def seed_of(s): return int(hashlib.md5(s.encode()).hexdigest()[:8], 16)

# ------------------------------------------------------------------ icone 16x16
OUT = (18, 14, 22)
def new(): return Image.new('RGBA', (16, 16), (0, 0, 0, 0))
def px(im, x, y, c):
    if 0 <= x < 16 and 0 <= y < 16: im.putpixel((x, y), tuple(c) + (255,) if len(c) == 3 else tuple(c))
def outline(im):
    src = im.copy()
    for y in range(16):
        for x in range(16):
            if src.getpixel((x, y))[3] == 0:
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < 16 and 0 <= ny < 16 and src.getpixel((nx, ny))[3] > 0: im.putpixel((x, y), OUT + (255,)); break
    return im
def pts(im, lst, c):
    for x, y in lst: px(im, x, y, c)
def disc(im, cx, cy, r, c):
    for y in range(16):
        for x in range(16):
            if (x - cx) ** 2 + (y - cy) ** 2 <= r * r: px(im, x, y, c)

def i_sword(a, b, c):
    im = new()
    for i in range(8): px(im, 13 - i, 1 + i, a); px(im, 12 - i, 1 + i, b)
    for k in range(-2, 3): px(im, 6 + k, 8 + k, c)
    for i in range(1, 4): px(im, 6 - i, 8 + i, sh(c, 0.7))
    return outline(im)
def _handle(im, c):
    for i in range(9): px(im, 3 + i, 13 - i, c)
def i_pick(a, b, c):
    im = new(); _handle(im, c)
    pts(im, [(5, 4), (6, 3), (7, 3), (8, 3), (9, 3), (10, 3), (11, 4), (12, 5), (13, 6), (13, 7)], a); pts(im, [(6, 4), (7, 4), (8, 4), (9, 4), (10, 4), (11, 5), (12, 6)], b)
    return outline(im)
def i_axe(a, b, c):
    im = new(); _handle(im, c)
    pts(im, [(7, 3), (8, 2), (9, 2), (10, 3), (11, 4), (11, 5), (10, 6), (9, 6), (8, 5), (8, 4), (9, 4), (9, 3), (10, 4), (10, 5)], a); pts(im, [(8, 5), (9, 5), (10, 5)], b)
    return outline(im)
def i_shovel(a, b, c):
    im = new(); _handle(im, c)
    pts(im, [(10, 2), (11, 2), (12, 3), (13, 4), (13, 5), (12, 5), (11, 4), (10, 3), (11, 3), (12, 4), (12, 2)], a); pts(im, [(12, 5), (13, 5), (12, 4)], b)
    return outline(im)
def i_hoe(a, b, c):
    im = new(); _handle(im, c)
    pts(im, [(8, 3), (9, 3), (10, 3), (11, 3), (12, 3), (12, 4), (8, 4)], a); pts(im, [(9, 4), (10, 4)], b)
    return outline(im)
def i_scythe(a, b, c):
    im = new()
    for i in range(12): px(im, 3 + i // 1 if False else 3 + i, 13 - i, c) if i < 10 else None
    pts(im, [(4, 4), (5, 3), (6, 2), (7, 2), (8, 2), (9, 3), (10, 4), (5, 4), (6, 3), (7, 3), (8, 3), (9, 4)], a); pts(im, [(5, 5), (6, 4), (7, 4), (8, 4)], b)
    return outline(im)
def i_staff(core, wood):
    im = new()
    for i in range(11): px(im, 4 + i // 2 + (0), 14 - i, wood)
    disc(im, 9, 4, 2.2, core); px(im, 8, 3, (255, 255, 255)); pts(im, [(7, 2), (11, 2), (7, 6), (11, 6)], sh(wood, 1.2))
    return outline(im)
def i_helmet(a, b):
    im = new()
    for y in range(3, 10):
        for x in range(3, 13): px(im, x, y, a if 4 <= x <= 11 and y < 9 else b)
    for y in (7, 8): [px(im, x, y, (10, 10, 14)) for x in range(5, 11)]
    for x in range(3, 5): px(im, x, 10, b); px(im, 12 - (x - 3), 10, b)
    return outline(im)
def i_chest(a, b):
    im = new()
    for y in range(2, 14):
        for x in range(4, 12): px(im, x, y, a)
    for y in range(2, 8):
        for x in (2, 3, 12, 13): px(im, x, y, b)
    for y in range(2, 5): [px(im, x, y, b) for x in range(6, 10)]
    for y in range(10, 14): [px(im, x, y, b) for x in (4, 5, 10, 11)]
    return outline(im)
def i_legs(a, b):
    im = new()
    for y in range(2, 5): [px(im, x, y, b) for x in range(3, 13)]
    for y in range(5, 14): [px(im, x, y, a) for x in list(range(3, 7)) + list(range(9, 13))]
    return outline(im)
def i_boots(a, b):
    im = new()
    for y in range(6, 12): [px(im, x, y, a) for x in list(range(3, 7)) + list(range(9, 13))]
    for y in range(12, 14): [px(im, x, y, b) for x in list(range(2, 7)) + list(range(9, 14))]
    return outline(im)
def i_shard(c):
    im = new(); pts(im, [(8, 2), (7, 3), (8, 3), (9, 3), (7, 4), (8, 4), (9, 4), (6, 5), (7, 5), (8, 5), (9, 5), (10, 5), (7, 6), (8, 6), (9, 6), (7, 7), (8, 7), (8, 8), (8, 9), (7, 10), (8, 10), (8, 11)], c)
    pts(im, [(8, 3), (8, 4), (8, 5)], sh(c, 1.3)); pts(im, [(9, 5), (9, 6), (8, 7)], sh(c, 0.7))
    return outline(im)
def i_ingot(a, b):
    im = new()
    for y in range(6, 11): [px(im, x, y, a) for x in range(3, 13)]
    for x in range(3, 13): px(im, x, 10, b); px(im, x, 6, sh(a, 1.25))
    return outline(im)
def i_orb(a, b):
    im = new(); disc(im, 8, 8, 5, b); disc(im, 8, 8, 4, a); disc(im, 8, 8, 2, sh(a, 1.4)); px(im, 6, 6, (255, 255, 255))
    return outline(im)
def i_gem(c):
    im = new(); pts(im, [(5, 4), (6, 4), (9, 4), (10, 4), (4, 5), (5, 5), (6, 5), (7, 5), (8, 5), (9, 5), (10, 5), (11, 5), (5, 6), (6, 6), (7, 6), (8, 6), (9, 6), (10, 6), (6, 7), (7, 7), (8, 7), (9, 7), (7, 8), (8, 8), (7, 9), (8, 9)], c)
    pts(im, [(7, 4), (8, 4), (7, 5), (8, 5)], sh(c, 1.3)); pts(im, [(9, 6), (10, 6), (8, 8)], sh(c, 0.7))
    return outline(im)
def i_eye(c):
    im = new()
    for x in range(2, 14):
        h = 3 - abs(x - 7.5) * 0.4
        for y in range(int(8 - h), int(8 + h) + 1): px(im, x, y, c)
    disc(im, 8, 8, 2, sh(c, 0.35)); px(im, 8, 8, (10, 10, 14)); px(im, 7, 7, (255, 255, 255))
    return outline(im)
def i_rune(c):
    im = new()
    for y in range(2, 14): [px(im, x, y, (84, 84, 98)) for x in range(4, 12)]
    for y in range(2, 14): px(im, 4, y, (60, 60, 72)); px(im, 11, y, (110, 110, 126))
    pts(im, [(8, 4), (8, 5), (8, 6), (7, 6), (9, 6), (8, 7), (7, 8), (9, 8), (8, 9), (8, 10), (7, 11), (9, 11)], c)
    return outline(im)
def i_artifact(c):
    im = new()
    for a in range(0, 360, 20):
        import math; px(im, int(8 + 5 * math.cos(math.radians(a))), int(8 + 5 * math.sin(math.radians(a))), sh(c, 0.8))
    disc(im, 8, 8, 2.5, c); px(im, 7, 7, (255, 255, 255)); pts(im, [(8, 1), (8, 15), (1, 8), (15, 8)], sh(c, 1.2))
    return outline(im)
def i_vial(c):
    im = new()
    for y in range(7, 13): [px(im, x, y, (190, 220, 235)) for x in range(5, 11)]
    for y in range(8, 13): [px(im, x, y, c) for x in range(6, 10)]
    for y in range(3, 7): [px(im, x, y, (190, 220, 235)) for x in (7, 8)]
    pts(im, [(7, 2), (8, 2)], (120, 80, 50)); px(im, 6, 8, (255, 255, 255))
    return outline(im)
def i_pearl(c):
    im = new(); disc(im, 8, 8, 5, sh(c, 0.6)); disc(im, 8, 8, 4, c); px(im, 6, 6, (255, 255, 255)); px(im, 7, 6, sh(c, 1.5))
    return outline(im)
def i_key(c):
    im = new(); disc(im, 5, 5, 3, c); disc(im, 5, 5, 1, (0, 0, 0, 0)) if False else None
    for i in range(8): px(im, 7 + i // 1, 7 + i, c) if False else None
    for i in range(9): px(im, 7 + i // 1, 7 + i // 1, c)
    pts(im, [(11, 12), (12, 11), (13, 12), (13, 13)], sh(c, 0.8)); px(im, 5, 5, (0, 0, 0)); px(im, 4, 4, sh(c, 1.4))
    return outline(im)
def i_book(c):
    im = new()
    for y in range(2, 14): [px(im, x, y, c) for x in range(3, 13)]
    for y in range(2, 14): px(im, 3, y, sh(c, 0.6)); px(im, 4, y, sh(c, 0.8))
    for x in range(5, 12): px(im, x, 13, (230, 220, 190))
    pts(im, [(7, 5), (8, 5), (9, 5), (8, 6), (8, 7), (8, 8), (7, 8), (9, 8)], (210, 170, 70))
    return outline(im)
def i_apple(a, b):
    im = new(); disc(im, 6, 9, 3.6, a); disc(im, 10, 9, 3.6, a); pts(im, [(8, 5), (8, 4), (9, 3)], (90, 60, 30)); pts(im, [(10, 3), (11, 3), (11, 4)], (70, 170, 70))
    pts(im, [(5, 7), (6, 7), (5, 8)], b)
    return outline(im)
def i_bread(a):
    im = new()
    for y in range(6, 12):
        for x in range(2, 14):
            if not ((x < 4 and y < 7) or (x > 11 and y < 7) or (x < 3 and y > 10) or (x > 12 and y > 10)): px(im, x, y, a)
    for x in range(4, 12, 3): [px(im, x, y, sh(a, 0.78)) for y in (7, 8)]
    for x in range(2, 14): px(im, x, 11, sh(a, 0.7))
    return outline(im)
def i_bowl(a):
    im = new()
    for y in range(8, 13): [px(im, x, y, (140, 100, 70)) for x in range(3 + (y - 8) // 2 * 0 + (12 - y) // 3, 13 - (12 - y) // 3)]
    for x in range(4, 12): px(im, x, 8, a); px(im, x, 7, sh(a, 1.3))
    return outline(im)
def i_berries(a):
    im = new()
    for cx, cy in ((5, 6), (10, 6), (7, 10), (11, 11)): disc(im, cx, cy, 2.2, a); px(im, cx - 1, cy - 1, (255, 255, 255))
    pts(im, [(7, 3), (8, 3), (8, 4)], (70, 150, 70))
    return outline(im)
def i_meat(a):
    im = new(); disc(im, 6, 6, 4, a); disc(im, 6, 6, 2, sh(a, 1.3))
    for i in range(5): px(im, 9 + i, 9 + i // 1, (225, 215, 200)) if i < 4 else None
    pts(im, [(13, 12), (14, 12), (13, 14), (14, 14)], (225, 215, 200))
    return outline(im)
def i_cookie(a):
    im = new(); disc(im, 8, 8, 5.5, sh(a, 0.75)); disc(im, 8, 8, 4.5, a)
    pts(im, [(6, 6), (10, 7), (7, 10), (11, 10), (5, 9)], sh(a, 0.45))
    return outline(im)
def i_egg(a, b):
    im = new()
    for y in range(2, 15):
        w = int(5.2 * (1 - ((y - 8.5) / 6.5) ** 2) ** 0.5 + 0.5)
        for x in range(8 - w, 8 + w): px(im, x, y, a)
    pts(im, [(6, 6), (9, 5), (7, 9), (10, 10), (5, 11), (8, 12)], b); pts(im, [(7, 4), (8, 4)], sh(a, 1.3))
    return outline(im)
ICONS = {'sword': i_sword, 'pick': i_pick, 'axe': i_axe, 'shovel': i_shovel, 'hoe': i_hoe, 'scythe': i_scythe, 'staff': i_staff, 'helmet': i_helmet, 'chest': i_chest,
         'legs': i_legs, 'boots': i_boots, 'shard': i_shard, 'ingot': i_ingot, 'orb': i_orb, 'gem': i_gem, 'eye': i_eye, 'rune': i_rune, 'artifact': i_artifact,
         'vial': i_vial, 'pearl': i_pearl, 'key': i_key, 'book': i_book, 'apple': i_apple, 'bread': i_bread, 'bowl': i_bowl, 'berries': i_berries,
         'meat': i_meat, 'cookie': i_cookie, 'egg': i_egg}
def icon(spec):
    name, *cols = spec.split(':')
    return ICONS[name](*[hexc(c) for c in cols])

# ------------------------------------------------------------------ blocchi 16x16
def block_tex(style, name):
    r = random.Random(seed_of(name)); im = Image.new('RGBA', (16, 16), (0, 0, 0, 255))
    base = {'dark': (24, 18, 32), 'cube': (40, 190, 80), 'rune': (92, 92, 104), 'arcane': (110, 66, 190), 'pedestal': (50, 44, 60), 'destiny': (22, 18, 30),
            'heart': (90, 14, 28), 'organic': (22, 64, 34), 'ore': (112, 112, 116), 'ritual': (38, 38, 48), 'trace': (10, 10, 14), 'eyeblock': (6, 6, 10)}[style]
    for y in range(16):
        for x in range(16): im.putpixel((x, y), jit(base, r, 10) + (255,))
    def P(x, y, c): im.putpixel((x % 16, y % 16), tuple(c) + (255,))
    if style == 'dark':
        for _ in range(10): P(r.randint(0, 15), r.randint(0, 15), (60, 30, 90))
    elif style == 'cube':
        for i in range(16): [P(i, k, (20, 120, 50)) for k in (0, 15)]; [P(k, i, (20, 120, 50)) for k in (0, 15)]
        for x in range(5, 11):
            for y in range(5, 11): P(x, y, (150, 255, 170))
    elif style in ('rune', 'ritual'):
        c = (185, 140, 255) if style == 'rune' else (240, 240, 240)
        for p_ in [(8, 3), (8, 4), (8, 5), (7, 6), (9, 6), (8, 7), (8, 8), (7, 9), (9, 9), (8, 10), (8, 11), (6, 12), (10, 12)]: P(*p_, c)
        if style == 'ritual':
            for x in range(5, 11): P(x, 7, c) if x not in (7, 8) else None
    elif style == 'arcane':
        for _ in range(14): P(r.randint(0, 15), r.randint(0, 15), (200, 160, 255))
        for i in range(16): P(i, i, (230, 200, 255))
    elif style == 'pedestal':
        for x in range(2, 14): P(x, 2, (212, 170, 70)); P(x, 13, (212, 170, 70))
        for y in range(2, 14): P(2, y, (212, 170, 70)); P(13, y, (212, 170, 70))
    elif style == 'destiny':
        for p_ in [(3, 3), (4, 3), (5, 3), (5, 4), (5, 5), (6, 5), (7, 5), (7, 6), (7, 7), (8, 7), (9, 7), (9, 8), (9, 9), (10, 9), (11, 9), (11, 10), (11, 11), (12, 11)]: P(*p_, (60, 255, 100))
    elif style == 'heart':
        for _ in range(16): P(r.randint(0, 15), r.randint(0, 15), (60, 255, 90))
        for x in range(6, 10):
            for y in range(6, 10): P(x, y, (255, 70, 90))
    elif style == 'organic':
        for _ in range(26): P(r.randint(0, 15), r.randint(0, 15), (40, 120, 60))
        for _ in range(8): P(r.randint(0, 15), r.randint(0, 15), (10, 30, 18))
    elif style == 'ore':
        for _ in range(9):
            x, y = r.randint(1, 14), r.randint(1, 14); P(x, y, (170, 220, 255)); P(x + 1, y, (120, 180, 240)); P(x, y + 1, (230, 245, 255))
    elif style == 'trace':
        for p_ in [(4, 4), (4, 5), (5, 5), (10, 9), (10, 10), (11, 10), (6, 12), (7, 12)]: P(*p_, (210, 210, 220))
    elif style == 'eyeblock':
        for x in range(2, 14):
            h = 4 - abs(x - 7.5) * 0.5
            for y in range(int(8 - h), int(8 + h) + 1): P(x, y, (245, 245, 250))
        for x in range(6, 10):
            for y in range(6, 10): P(x, y, (10, 10, 14))
    return im

def effect_icon(color, name):
    im = Image.new('RGBA', (18, 18), (0, 0, 0, 0)); c = hexc(color)
    for y in range(18):
        for x in range(18):
            d = ((x - 8.5) ** 2 + (y - 8.5) ** 2) ** 0.5
            if d <= 7.5: im.putpixel((x, y), (sh(c, 0.55) if d > 6 else sh(c, 1.0 if d > 3 else 1.3)) + (255,))
    if name == 'corruzione': [im.putpixel((x, 9), (10, 5, 20, 255)) for x in range(5, 13)]
    if name == 'scudo_eden': [im.putpixel((9, y), (255, 255, 255, 255)) for y in range(4, 14)]
    if name == 'sguardo': [im.putpixel((x, 9), (255, 255, 255, 255)) for x in range(5, 13)]
    if name == 'piaga': [im.putpixel((x, x), (10, 60, 20, 255)) for x in range(5, 13)]
    if name == 'maledizione_runica': [im.putpixel((9, y), (240, 220, 255, 255)) for y in range(5, 13)]
    return im

# ------------------------------------------------------------------ skin 64x64 procedurali
PARTS = {'head': ((0, 0), 8, 8, 8), 'hat': ((32, 0), 8, 8, 8), 'body': ((16, 16), 8, 12, 4), 'rarm': ((40, 16), 4, 12, 4), 'larm': ((32, 48), 4, 12, 4),
         'rleg': ((0, 16), 4, 12, 4), 'lleg': ((16, 48), 4, 12, 4)}
def faces(origin, w, h, d):
    ox, oy = origin
    return dict(top=(ox + d, oy, w, d), bottom=(ox + d + w, oy, w, d), right=(ox, oy + d, d, h), front=(ox + d, oy + d, w, h), left=(ox + d + w, oy + d, d, h), back=(ox + 2 * d + w, oy + d, w, h))
def fill_part(im, part, fn):
    origin, w, h, d = PARTS[part]
    for face, (fx, fy, fw, fh) in faces(origin, w, h, d).items():
        for y in range(fh):
            for x in range(fw):
                c = fn(face, x, y, fw, fh)
                if c is not None: im.putpixel((fx + x, fy + y), tuple(c) + (255,) if len(c) == 3 else tuple(c))
def put_front(im, part, x, y, c):
    origin, w, h, d = PARTS[part]; fx, fy, fw, fh = faces(origin, w, h, d)['front']; im.putpixel((fx + x, fy + y), tuple(c) + (255,))

def paint_mob(style, pal, name):
    r = random.Random(seed_of(name)); im = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
    base, acc, eye, det = [hexc(c) for c in pal]
    arm = lambda f, x, y, w, h: jit(base, r, 8)
    if style in ('zombie', 'bones', 'tentacle', 'demon'):
        skin = base
        for p_ in ('head', 'rarm', 'larm'): fill_part(im, p_, lambda f, x, y, w, h: jit(skin, r, 10))
        fill_part(im, 'body', lambda f, x, y, w, h: jit(acc, r, 10) if r.random() > 0.15 else jit(skin, r, 8))
        for p_ in ('rleg', 'lleg'): fill_part(im, p_, lambda f, x, y, w, h: jit(det, r, 8))
        for ex in (1, 2, 5, 6): put_front(im, 'head', ex, 3, eye)
        for mx in range(2, 6): put_front(im, 'head', mx, 6, sh(det, 0.5))
        if style == 'bones':
            for y in range(0, 12, 2): [put_front(im, 'body', x, y, sh(base, 0.5)) for x in range(8)]
        if style == 'demon':
            fill_part(im, 'hat', lambda f, x, y, w, h: acc if (f == 'top' and x in (1, 6)) or (f in ('front', 'back', 'left', 'right') and y == 0 and x in (1, 6)) else None)
            for mx in (2, 4, 5): put_front(im, 'head', mx, 7, (255, 255, 255))
        if style == 'tentacle':
            for _ in range(30): put_front(im, 'body', r.randint(0, 7), r.randint(0, 11), acc)
    elif style == 'armor':
        for p_ in ('head', 'body', 'rarm', 'larm', 'rleg', 'lleg'): fill_part(im, p_, lambda f, x, y, w, h: jit(base, r, 6) if (x + y) % 5 else acc)
        for ex in (1, 2, 5, 6): put_front(im, 'head', ex, 3, eye)
        for x in range(1, 7): put_front(im, 'head', x, 4, det)
        fill_part(im, 'hat', lambda f, x, y, w, h: det if y == 0 and f != 'bottom' and f != 'top' else None)
    elif style in ('shadow', 'raven'):
        for p_ in PARTS:
            if p_ != 'hat': fill_part(im, p_, lambda f, x, y, w, h: jit(base, r, 5))
        for ex in (1, 2, 5, 6): put_front(im, 'head', ex, 3, eye)
        if style == 'raven':
            for x in (3, 4): put_front(im, 'head', x, 4, eye); put_front(im, 'head', x, 5, eye)
    elif style == 'stone':
        for p_ in ('head', 'body', 'rarm', 'larm', 'rleg', 'lleg'): fill_part(im, p_, lambda f, x, y, w, h: jit(base, r, 14) if r.random() > 0.12 else sh(base, 0.6))
        for ex in (1, 2, 5, 6): put_front(im, 'head', ex, 3, eye)
        for p_ in [(3, 4), (3, 5), (4, 6)]: put_front(im, 'body', *p_, acc)
    elif style == 'robed':
        for p_ in ('head', 'body', 'rarm', 'larm', 'rleg', 'lleg'): fill_part(im, p_, lambda f, x, y, w, h: jit(base, r, 5))
        fill_part(im, 'head', lambda f, x, y, w, h: sh(base, 0.4) if f == 'front' and 1 <= x <= 6 and 1 <= y <= 6 else jit(base, r, 5))
        for ex in (2, 5): put_front(im, 'head', ex, 3, eye)
        for y in range(12): put_front(im, 'body', 3, y, acc)
    elif style == 'eye':
        for p_ in ('head', 'body', 'rarm', 'larm', 'rleg', 'lleg'): fill_part(im, p_, lambda f, x, y, w, h: jit(base, r, 6))
        for x in range(1, 7):
            for y in range(2, 6): put_front(im, 'head', x, y, (245, 245, 250))
        for x in (3, 4):
            for y in (3, 4): put_front(im, 'head', x, y, eye)
    elif style == 'ghost':
        for p_ in ('head', 'body', 'rarm', 'larm', 'rleg', 'lleg'): fill_part(im, p_, lambda f, x, y, w, h: jit(base if (x + y) % 3 else acc, r, 8))
        for ex in (2, 5): put_front(im, 'head', ex, 3, det); put_front(im, 'head', ex, 4, det)
        for x in (3, 4): put_front(im, 'head', x, 6, det)
    elif style == 'mech':
        for p_ in ('head', 'body', 'rarm', 'larm', 'rleg', 'lleg'): fill_part(im, p_, lambda f, x, y, w, h: jit(base, r, 5) if (x % 4 and y % 4) else det)
        for x in range(1, 7): put_front(im, 'head', x, 3, eye)
        for p_ in [(2, 3), (5, 3), (3, 6), (4, 6)]: put_front(im, 'body', *p_, eye)
    elif style == 'faceless':
        for p_ in ('head', 'rarm', 'larm'): fill_part(im, p_, lambda f, x, y, w, h: jit(base, r, 6))
        for p_ in ('body', 'rleg', 'lleg'): fill_part(im, p_, lambda f, x, y, w, h: jit(det, r, 6))
        for y in range(3, 12): put_front(im, 'body', 3, y, acc)
    else:  # fallback
        for p_ in ('head', 'body', 'rarm', 'larm', 'rleg', 'lleg'): fill_part(im, p_, lambda f, x, y, w, h: jit(base, r, 8))
    return im

# ------------------------------------------------------------------ skin dei sei protagonisti
def steve_skin(level):
    im = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
    HAIR, SK, SK2, BR, SHIRT, SHIRT2, PANT, PANT2, SHOE = [hexc(x) for x in ('3b2a1e', 'b38a6a', '9a7255', '4a3322', '1fa8a1', '168a85', '4b3fa8', '3a3088', '707070')]
    def head(f, x, y, w, h):
        if f in ('top', 'back'): return HAIR
        if f == 'bottom': return SK
        if f in ('left', 'right'): return HAIR if y < 3 else (HAIR if (x < 2 and f == 'left') or (x > 5 and f == 'right') else SK)
        if y < 2: return HAIR
        if y == 2: return HAIR if x in (0, 7) else SK
        if y == 3: return {1: (240, 240, 240), 2: hexc('4b3f9f'), 5: hexc('4b3f9f'), 6: (240, 240, 240)}.get(x, SK)
        if y == 4: return SK2 if x in (3, 4) else SK
        if y == 5: return SK if x in (0, 7) else BR
        if y == 6: return SK if x in (0, 7) else (sh(BR, 0.55) if 2 <= x <= 5 else BR)
        return SK if x in (0, 7) else BR
    fill_part(im, 'head', head)
    fill_part(im, 'body', lambda f, x, y, w, h: SHIRT if (x + y) % 7 else SHIRT2)
    for p_ in ('rarm', 'larm'): fill_part(im, p_, lambda f, x, y, w, h: (SHIRT if y < 4 else SK) if f not in ('top',) else SHIRT)
    for p_ in ('rleg', 'lleg'): fill_part(im, p_, lambda f, x, y, w, h: SHOE if y >= 10 and f not in ('top',) else (PANT if (x + y) % 6 else PANT2))
    if level >= 2:
        col = {2: hexc('cfd2d8'), 3: hexc('b9bde0'), 4: hexc('37313a'), 5: hexc('f3e7b0')}[level]
        trim = {2: hexc('8d9199'), 3: hexc('7a4bc8'), 4: hexc('8a4fff'), 5: hexc('ffffff')}[level]
        fill_part(im, 'body', lambda f, x, y, w, h: col if (f in ('front', 'back') and 1 <= y <= 9 and 0 <= x <= 7) and ((x + y) % 5 or True) else None)
        fill_part(im, 'body', lambda f, x, y, w, h: trim if f in ('front', 'back') and (y in (1, 9) or x in (0, 7)) else None)
        fill_part(im, 'hat', lambda f, x, y, w, h: col if (f in ('top',) or (f in ('front', 'back', 'left', 'right') and y < 3)) else None)
        for p_ in ('rleg', 'lleg'): fill_part(im, p_, lambda f, x, y, w, h: col if y >= 9 and f != 'top' else None)
        for p_ in ('rarm', 'larm'): fill_part(im, p_, lambda f, x, y, w, h: col if y < 2 and f != 'bottom' else None)
        if level >= 3:
            r = random.Random(level)
            for _ in range(14): put_front(im, 'body', r.randint(0, 7), r.randint(1, 9), trim)
    return im

def observer_skin():
    r = random.Random(7); im = Image.new('RGBA', (64, 64), (0, 0, 0, 0)); K = (10, 10, 13)
    for p_ in ('head', 'body', 'rarm', 'larm', 'rleg', 'lleg'): fill_part(im, p_, lambda f, x, y, w, h: jit(K, r, 3))
    fill_part(im, 'hat', lambda f, x, y, w, h: jit((6, 6, 8), r, 2) if f in ('top', 'back', 'left', 'right') or (f == 'front' and y < 2) else None)
    for ex in (1, 2, 5, 6): put_front(im, 'head', ex, 3, (255, 255, 255))
    for ex in (1, 6): put_front(im, 'head', ex, 4, (200, 200, 210))
    return im

def wizard_skin():
    r = random.Random(11); W = Image.new('RGBA', (128, 128), (0, 0, 0, 0))
    PUR, PUR2, GOLD, DARK, SKIN, EYE = hexc('3b1c7a'), hexc('5a2ea6'), hexc('d9a441'), hexc('1a1228'), hexc('f0c8b0'), hexc('a070ff')
    def head(f, x, y, w, h):
        if f in ('top', 'back'): return hexc('0d0d12')
        if f == 'bottom': return SKIN
        if f in ('left', 'right'): return hexc('0d0d12') if y < 4 or x in (0, 7) else (PUR2 if y > 4 else SKIN)
        if y < 2: return hexc('0d0d12')
        if y == 2: return hexc('0d0d12') if x in (0, 1, 6, 7) else SKIN
        if y == 3: return EYE if x in (2, 5) else (hexc('0d0d12') if x in (0, 7) else SKIN)
        if y == 4: return EYE if x in (2, 5) else SKIN
        return PUR2 if y >= 5 else SKIN        # sciarpa viola sul viso
    fill_part(W, 'head', head)
    fill_part(W, 'body', lambda f, x, y, w, h: DARK if f == 'front' and 3 <= x <= 4 else (GOLD if f == 'front' and x in (2, 5) else jit(PUR if (x + y) % 6 else PUR2, r, 6)))
    for p_ in ('rarm', 'larm'): fill_part(W, p_, lambda f, x, y, w, h: GOLD if y in (9, 10) and f not in ('top', 'bottom') else (SKIN if y == 11 else jit(PUR if (x + y) % 5 else PUR2, r, 6)))
    for p_ in ('rleg', 'lleg'): fill_part(W, p_, lambda f, x, y, w, h: GOLD if y == 11 and f == 'front' else (DARK if y < 9 else jit(PUR, r, 5)))
    for x in range(64, 128):          # texture del cappello a punta (parti 64..127, 0..44)
        for y in range(0, 45): W.putpixel((x, y), jit(PUR if (x + y) % 7 else PUR2, r, 6) + (255,))
    for x in range(64, 120): W.putpixel((x, 8), GOLD + (255,)); W.putpixel((x, 7), GOLD + (255,)) if 64 <= x < 92 else None
    for y in range(16, 28):
        for x in range(64, 96):
            if y == 22: W.putpixel((x, y), GOLD + (255,))
    for p_ in [(76, 20), (77, 19), (77, 20), (77, 21), (78, 20), (79, 20)]: W.putpixel(p_, GOLD + (255,))
    for y in range(46, 68):          # mantello: facce 'dietro' con luna e croce dorate
        for x in range(64, 90):
            if y < 128: W.putpixel((x, y), jit(PUR if (x + y) % 9 else PUR2, r, 5) + (255,))
    for p_ in [(80, 52), (79, 52), (78, 53), (78, 54), (78, 55), (79, 56), (80, 56), (81, 57)]: W.putpixel(p_, GOLD + (255,))
    for y in range(58, 66): W.putpixel((83, y), GOLD + (255,))
    for x in range(80, 87): W.putpixel((x, 61), GOLD + (255,))
    for x in range(64, 90): W.putpixel((x, 67), GOLD + (255,))
    return W

def armor_layer(kind):
    im = Image.new('RGBA', (64, 32), (0, 0, 0, 0)); r = random.Random(5 if kind == 1 else 6)
    base, acc, glow = hexc('2c7a3c'), hexc('1a4a26'), hexc('7dff8a')
    for y in range(32):
        for x in range(64):
            c = jit(base, r, 8)
            if x % 8 == 0 or y % 8 == 0: c = acc
            if (x * 7 + y * 13) % 29 == 0: c = glow
            im.putpixel((x, y), c + (255,))
    return im
def adv_bg():
    r = random.Random(3); im = Image.new('RGBA', (16, 16), (0, 0, 0, 255))
    for y in range(16):
        for x in range(16): im.putpixel((x, y), jit((22, 18, 34), r, 7) + (255,))
    for _ in range(6): im.putpixel((r.randint(0, 15), r.randint(0, 15)), (60, 255, 100, 255))
    return im
