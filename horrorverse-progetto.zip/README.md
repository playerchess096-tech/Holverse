# Horror Universe — mod NeoForge per Minecraft Java 26.3

Sei entità intelligenti con skin tue, boss fight a livelli, presenza autonoma nel mondo, mostri, armi, cibi, strutture, achievement, musiche.
**Stato onesto: il codice NON è stato compilato né provato in gioco** (nel mio ambiente non c'era rete né Minecraft). Ho solo controllato la sintassi
Java e che ogni classe del mod usi correttamente le altre. Alla prima build possono uscire errori su nomi di API di NeoForge 26.3: incollali a Claude
(vedi "Punti delicati" in fondo) e si correggono in pochi minuti.

## Compilare da telefono (GitHub Actions)
1. Crea un repo su GitHub (o usa uno nuovo).
2. Carica **horrorverse-progetto.zip così com'è** nella radice del repo (Add file → Upload files). Non serve estrarlo.
3. Crea il file `.github/workflows/build.yml` (Add file → Create new file, scrivi il nome con le barre) e incolla il contenuto di `build-da-incollare.yml`.
   Il workflow estrae lo ZIP da solo, cerca l'ultima versione di NeoForge 26.3.x, compila con Java 25.
4. Se compila: scheda **Releases** del repo → l'ultima build → scarichi direttamente `horrorverse-1.0.0.jar` (circa 9 MB). Se fallisce: apri l'esecuzione → **Summary** → copia il blocco degli errori.
5. Metti il .jar nella cartella `mods` di Minecraft 26.3 con NeoForge 26.3.x.

## Come si gioca
* Tutto parte dall'**ordine narrativo** (capitoli, config `ordineNarrativo`): 1 Osservatore e Steve → 2 Custode (dopo ~20 min di gioco) → 3 Uomo Magico → 4 Corrotto → 5 Entity 404 (nemico finale).
  Prima di ogni introduzione ci sono avvistamenti e indizi; Entity 404 è anticipato da numeri verdi in chat e piccoli segni.
* Hai un **Diario del Mondo** (clic destro): mostra la lore sbloccata (30 pagine). `/horror diario`, `/horror status`.
* Profili: `/horror intensita leggero|standard|intenso`, `/horror jumpscare on|off`, `/horror scuotimento on|off`. Tutto il resto è in `config/horrorverse-startup.toml`.
* Debug (Creativa): `/horror summon <osservatore|steve|custode|uomo_magico|corrotto|entity_404> <livello>`, `/horror capitolo <1-5>`, `/horror minion <id>`, `/horror reset`.
* Uova di generazione per le sei entità nella scheda creativa **Horror Universe**.

## Skin
Entity 404: skin verde (livelli 1–3) e demone verde (livello 4+). Custode: occhi bianchi. Corrotto: smoking (amichevole) → metà corrotto → scuro (Dio dell'Oscurità).
Uomo Magico: mago viola con cappello e mantello (modello 3D). Steve: classico, con 5 varianti per livello. **Osservatore: non c'era una skin tra le tue, ne ho disegnata una**
(silhouette nera, occhi bianchi, un po' più alto). Nessuna skin di Herobrine. Le skin sono ricostruite dalle tue immagini (campionamento), gli occhi non sono "luminosi".

## Regole armi (Parte 9)
Attacco = valore reale dell'arma in mano (funziona anche con armi di altre mod). Colpi validi: mai doppi (almeno 8 tick), solo se l'entità è vulnerabile.
| Entità | Normali | Spada Antivirus (L3) | Lama Quarantena (L6) |
|---|---|---|---|
| Custode 1 | qualsiasi | 1 | 1 |
| Zombie del Custode | – | 2 | 1 |
| Custode 3 / 4 | attacco ≥7 / ≥8 (netherite) | 2 / 3 | 1 / 1 |
| Custode 5 | immune: solo 10 perle valide | – | – |
| Corrotto 1-2 | non attaccabile | 2 | 1 |
| Corrotto 3 / 4 / 5 | solo nelle finestre (artefatto) | 3 / 1 / 4 | 1 / 1 / 2 |
| Clone di 404 | – | 4 | 2 |
| Entity 404 L3 / L4 | solo nelle finestre | 4 / 3 | 2 / 3 |
| Entity 404 L6 (valori miei) | – | 12 | 6 |
| Entity 404 L7 | – | 20 | 10 (servono 5 Statue del Destino) |
Uomo Magico: rune/generatori distrutti prima; L4 attacco ≥7 (diamante). Steve: nessuna immunità. Osservatore: non si combatte.

## Contraddizioni trovate (non ho cambiato le regole di nascosto)
1. **Corrotto L1-L2**: "non attaccabile" ma la tabella dà 2/1 colpi. → Ho tenuto entrambe: attaccabile solo con le due armi speciali.
2. **Soglia "attacco >7" vs spada di diamante (7)**: l'Uomo Magico L4 deve morire con diamante. → Soglie per entità e configurabili (Custode ≥8, Mago ≥7).
3. **Steve**: la nuova lore dice "non antagonista, non studia il giocatore"; il prompt originale lo vuole rivale con IA che impara le tattiche.
   → Ho seguito l'originale (livelli, adattamento alle tue armi, depositi) ma lo ho presentato come "prove" tra sopravvissuti, con dialoghi non ostili e tregua finale. Da decidere se togliere l'adattamento.
4. **Uomo Magico**: originale "ossessionato dalla conoscenza, può diventare alleato" vs nuova "avido, acido, antagonista". → Tenuto il patto (4 oro → runa), tono avido.
5. **Occhi bianchi**: nuova lore li attribuisce all'oscurità primordiale dell'Osservatore, il Custode ha ottenuto "il potere degli Occhi Bianchi". → Raccordo proposto: la forza antica è l'oscurità dell'Osservatore. Nessuna meccanica toccata.
6. **Custode ucciso al L4** chiude il Rituale (L5): scelta definitiva, come da prompt.
7. Morte permanente, uccisione in Creativa, distruzione del mondo: implementate ma **spente** di default (config) e mai distruttive per il salvataggio.

## Cosa c'è / cosa manca
**C'è**: 6 entità + presenza autonoma; Custode L1-5 (ondate, contatto ×3 con dedupe, scettro, fasi, scelta risparmia/uccidi, rituale con 10 perle valide, oggetti-fantasma reversibili);
Corrotto L1-5 (statue che si muovono se non guardate, blocchi oscuri, oggetti corrotti/purificabili, furto temporaneo reversibile, anima, fiducia da regali e chat);
Entity 404 L1-L7 + livello bonus con clone che si convince in chat + tasca-dimensione; Uomo Magico L1-5 (illusioni, rune, generatori, piedistallo); Steve L1-5 (depositi, tre prove, tregua);
Osservatore (eventi, 3 prove); 41 mostri; 44 oggetti (armi, set Spettrale, armatura Antivirus, cibi, artefatti); 12 blocchi; 6 effetti; 26 suoni/musiche; 25 ricette; 58 achievement;
7 strutture/zone + minerale; config; comandi.
**Semplificato**: la "dimensione" di Entity 404 è una piattaforma lontana nell'Overworld; le "zone" (Landa Cinerea, Macchia Corrotta) sono macchie generate, non biomi veri;
gli occhi non sono luminosi; Steve non costruisce ponti/torri; L7 senza barriere distruttibili, portali, clone alleato.
**Manca**: biomi JSON veri e seed personalizzati (il formato dei biomi di 26.3 non era verificabile senza avviare il gioco: un JSON sbagliato romperebbe tutti i mondi);
circa 50 dei ~90 mostri del prompt; modelli 3D non umanoidi; integrazione con altre mod oltre alle armi e al tag dei boss.

## Punti delicati se la build dà errori (tutti isolati)
`Fx.java` (teleportTo, advancement, messaggi/suoni), `Store.java` (percorso del mondo), `Reg.java`/`ModBlocks.java` (registrazioni), `Mats.java` (ToolMaterial/ArmorMaterial),
`HorrorModel.java`/`HRenderer.java` (rendering), `ModItems.java` (sword/pickaxe/axe/humanoidArmor/spawnEgg), nomi degli eventi in `Events.java`.

Nota (prima correzione dopo il tuo log, 55 errori): le strutture, le macchie e il minerale ora si generano da codice (nessun JSON di worldgen), i progressi stanno in
`horrorverse_data.txt` nella cartella del mondo, la config è di tipo STARTUP (file `config/horrorverse-startup.toml`), e le entità vanilla si cercano per nome.

I valori di `tools/` (gen*.py) rigenerano texture, suoni, JSON e i registri Java: `python3 tools/gen.py` e `python3 tools/gen_audio.py`.
